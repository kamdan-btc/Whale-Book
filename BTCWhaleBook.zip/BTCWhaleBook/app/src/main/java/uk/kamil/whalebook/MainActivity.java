package uk.kamil.whalebook;

import android.Manifest;
import android.app.Activity;
import android.content.ContentValues;
import android.os.Environment;
import android.provider.MediaStore;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    private WebView web;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        web = new WebView(this);
        web.setBackgroundColor(0xFF0D1117);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);                // remembers your settings
        s.setAllowFileAccess(true);
        s.setAllowUniversalAccessFromFileURLs(true);  // lets the page call exchange APIs directly
        s.setCacheMode(WebSettings.LOAD_NO_CACHE);    // always fresh data
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new Bridge(), "Android");
        setContentView(web);
        if (savedInstanceState != null) web.restoreState(savedInstanceState);
        else web.loadUrl("file:///android_asset/index.html");

        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
        // restart the watcher if it was on but Android stopped it
        if (Prefs.enabled(this)) WhaleService.start(this);
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        web.saveState(out);
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    /** Functions the dashboard can call as window.Android.* */
    public class Bridge {
        private Context ctx() {
            return MainActivity.this;
        }

        @JavascriptInterface
        public String getSettings() {
            return Prefs.settings(ctx()).toString();
        }

        @JavascriptInterface
        public void setSettings(String json) {
            Prefs.saveSettings(ctx(), json);
        }

        @JavascriptInterface
        public String getAlerts() {
            return Prefs.alerts(ctx());
        }

        @JavascriptInterface
        public void clearAlerts() {
            Prefs.clearAlerts(ctx());
        }

        @JavascriptInterface
        public boolean isRunning() {
            return Prefs.enabled(ctx());
        }

        @JavascriptInterface
        public void startAlerts() {
            Prefs.setEnabled(ctx(), true);
            WhaleService.start(ctx());
        }

        @JavascriptInterface
        public void stopAlerts() {
            Prefs.setEnabled(ctx(), false);
            stopService(new Intent(ctx(), WhaleService.class));
        }

        @JavascriptInterface
        public void openBatterySettings() {
            try {
                PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
                Intent i;
                if (!pm.isIgnoringBatteryOptimizations(getPackageName())) {
                    i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + getPackageName()));
                } else {
                    i = new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS);
                }
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
            } catch (Exception e) {
                openAppSettings();
            }
        }

        /** Finished days saved for a coin, as a JSON object keyed by date. */
        @JavascriptInterface
        public String getDays(String coin) {
            return Prefs.getDays(ctx(), coin);
        }

        /** Saves a finished day worked out by the page (ignored if that day is already saved). */
        @JavascriptInterface
        public boolean saveDay(String coin, String date, String json) {
            return Prefs.saveDay(ctx(), coin, date, json);
        }

        /** Saves a CSV (or any text) file to Downloads/Whale Book and returns a message for the page to show. */
        @JavascriptInterface
        public String saveFile(String name, String content) {
            String safe = name.replaceAll("[^A-Za-z0-9._-]", "_");
            try {
                byte[] data = content.getBytes("UTF-8");
                if (Build.VERSION.SDK_INT >= 29) {
                    ContentValues v = new ContentValues();
                    v.put(MediaStore.MediaColumns.DISPLAY_NAME, safe);
                    v.put(MediaStore.MediaColumns.MIME_TYPE, "text/csv");
                    v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Whale Book");
                    Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                    if (uri == null) return "Couldn't create the file in Downloads.";
                    try (java.io.OutputStream os = getContentResolver().openOutputStream(uri)) {
                        os.write(data);
                    }
                    return "Saved to Downloads/Whale Book/" + safe;
                }
                // Android 8-9: save in the app's own Downloads folder
                java.io.File dir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
                java.io.File f = new java.io.File(dir, safe);
                try (java.io.FileOutputStream os = new java.io.FileOutputStream(f)) {
                    os.write(data);
                }
                return "Saved to " + f.getAbsolutePath();
            } catch (Exception e) {
                return "Couldn't save the file: " + e.getMessage();
            }
        }

        @JavascriptInterface
        public void openAppSettings() {
            try {
                Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName()));
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
            } catch (Exception ignored) {
            }
        }
    }
}
