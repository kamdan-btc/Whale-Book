package uk.kamil.whalebook;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

/** Settings and alert history shared between the dashboard and the background service. */
final class Prefs {
    private static final String FILE = "whalebook";
    private static final int MAX_ALERTS = 60;

    private Prefs() {}

    private static SharedPreferences sp(Context c) {
        return c.getApplicationContext().getSharedPreferences(FILE, Context.MODE_PRIVATE);
    }

    static JSONObject settings(Context c) {
        try {
            return new JSONObject(sp(c).getString("settings", "{}"));
        } catch (Exception e) {
            return new JSONObject();
        }
    }

    static void saveSettings(Context c, String json) {
        try {
            new JSONObject(json); // validate
            sp(c).edit().putString("settings", json).apply();
        } catch (Exception ignored) {
        }
    }

    static boolean enabled(Context c) {
        return sp(c).getBoolean("enabled", false);
    }

    static void setEnabled(Context c, boolean on) {
        sp(c).edit().putBoolean("enabled", on).apply();
    }

    static String alerts(Context c) {
        return sp(c).getString("alerts", "[]");
    }

    static void clearAlerts(Context c) {
        sp(c).edit().putString("alerts", "[]").apply();
    }

    static synchronized void addAlert(Context c, String kind, String title, String text) {
        try {
            JSONArray old = new JSONArray(alerts(c));
            JSONArray out = new JSONArray();
            JSONObject a = new JSONObject();
            a.put("t", System.currentTimeMillis());
            a.put("kind", kind);
            a.put("title", title);
            a.put("text", text);
            out.put(a);
            for (int i = 0; i < old.length() && out.length() < MAX_ALERTS; i++) out.put(old.get(i));
            sp(c).edit().putString("alerts", out.toString()).apply();
        } catch (Exception ignored) {
        }
    }
}
