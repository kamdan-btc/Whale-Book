package uk.kamil.whalebook;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Restarts the background alerts after the phone reboots, if they were on. */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        if (Intent.ACTION_BOOT_COMPLETED.equals(i.getAction()) && Prefs.enabled(c)) {
            try {
                WhaleService.start(c);
            } catch (Exception ignored) {
            }
        }
    }
}
