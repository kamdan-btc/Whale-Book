package uk.kamil.whalebook;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * BTC ETF flow reads. Same rules and arithmetic as the dashboard's ETF tab (etfParse / etfCompute / etfRead),
 * so a notification always matches what the tab shows.
 * Data: The Commoner Bitcoin ETF Tracker by TFTC (CC BY 4.0).
 */
final class EtfLogic {
    static final String DATA_URL = "https://www.tftc.io/bitcoin-etf-flows/data.json";
    static final String LATEST_URL = "https://www.tftc.io/bitcoin-etf-flows/latest.json";
    static final int W = 120, MIN = 60;

    private EtfLogic() {}

    static final class Day {
        String date;
        double net;      // $ millions
        double close;    // BTC price
        final Map<String, Double> funds = new LinkedHashMap<>(); // $ millions
    }

    /** codes in the same order as the dashboard: {title, icon} */
    static String[] info(String code) {
        switch (code) {
            case "dip_bought": return new String[]{"Dip being bought", "🟢"};
            case "rally_unbacked": return new String[]{"Rally without ETF buyers", "🔴"};
            case "quiet_accum": return new String[]{"Quiet accumulation", "🔵"};
            case "quiet_dist": return new String[]{"Quiet distribution", "🟠"};
            case "selling_drop": return new String[]{"ETFs selling into the drop", "🔻"};
            case "chasing": return new String[]{"ETFs chasing the rally", "🔺"};
            default: return new String[]{"No ETF signal", "⚪"};
        }
    }

    static String meaning(String code) {
        switch (code) {
            case "dip_bought": return "Price fell 5%+ over 5 sessions but ETFs kept net buying.";
            case "rally_unbacked": return "Price rose 5%+ over 5 sessions while ETFs were net sellers.";
            case "quiet_accum": return "Price sideways while ETF buying is in the strongest 20% of the last 120 sessions.";
            case "quiet_dist": return "Price sideways while ETF selling is in the heaviest 20% of the last 120 sessions.";
            case "selling_drop": return "Heavy ETF selling confirms the drop. Not a bottom signal on its own.";
            case "chasing": return "Strong ETF buying confirms the rally, but the week or two after has often been flat.";
            default: return "Flows are moving with price.";
        }
    }

    static List<Day> parse(String json) throws Exception {
        JSONObject d = new JSONObject(json);
        JSONArray raw = d.optJSONArray("days");
        List<Day> days = new ArrayList<>();
        if (raw == null) return days;
        for (int i = 0; i < raw.length(); i++) {
            JSONObject x = raw.optJSONObject(i);
            if (x == null) continue;
            String date = x.optString("date", "");
            if (!date.matches("\\d{4}-\\d{2}-\\d{2}")) continue;
            if (x.isNull("netFlowUsd")) continue;
            double net = x.optDouble("netFlowUsd", Double.NaN);
            if (Double.isNaN(net) || Double.isInfinite(net)) continue;
            Day day = new Day();
            boolean any = net != 0;
            JSONObject f = x.optJSONObject("perEtfUsd");
            if (f != null) {
                Iterator<String> it = f.keys();
                while (it.hasNext()) {
                    String k = it.next();
                    if (f.isNull(k)) continue;
                    double v = f.optDouble(k, Double.NaN);
                    if (Double.isNaN(v) || Double.isInfinite(v)) continue;
                    day.funds.put(k, v / 1e6);
                    if (v != 0) any = true;
                }
            }
            if (!any) continue; // market holiday
            day.date = date;
            day.net = net / 1e6;
            double c = x.isNull("btcCloseUsd") ? 0 : x.optDouble("btcCloseUsd", 0);
            day.close = c > 0 ? c : -1;
            days.add(day);
        }
        Collections.sort(days, (a, b) -> a.date.compareTo(b.date));
        for (int i = 0; i < days.size(); i++) if (days.get(i).close < 0) days.get(i).close = i > 0 ? days.get(i - 1).close : -1;
        List<Day> out = new ArrayList<>();
        for (Day x : days) if (x.close > 0) out.add(x);
        return out;
    }

    static Double pctile(Double[] a, int i) {
        if (a[i] == null) return null;
        int n = 0, below = 0;
        for (int j = Math.max(0, i - W); j < i; j++) {
            if (a[j] == null) continue;
            n++;
            if (a[j] < a[i]) below++;
        }
        return n >= MIN ? below / (double) n * 100 : null;
    }

    static String read(Double s5, Double pc5, Double p5) {
        if (s5 == null || pc5 == null) return "none";
        if (pc5 <= -5 && s5 > 0) return "dip_bought";
        if (pc5 >= 5 && s5 < 0) return "rally_unbacked";
        if (Math.abs(pc5) < 2 && p5 != null && p5 >= 80 && s5 > 0) return "quiet_accum";
        if (Math.abs(pc5) < 2 && p5 != null && p5 <= 20 && s5 < 0) return "quiet_dist";
        if (pc5 <= -5 && p5 != null && p5 <= 20) return "selling_drop";
        if (pc5 >= 5 && p5 != null && p5 >= 80) return "chasing";
        return "none";
    }

    /** Everything worked out per session. */
    static final class Metrics {
        List<Day> days;
        double[] F, P;
        Double[] S5, PC5, P5, PD;
        String[] R;
    }

    static Metrics compute(List<Day> days) {
        int n = days.size();
        Metrics m = new Metrics();
        m.days = days;
        m.F = new double[n];
        m.P = new double[n];
        m.S5 = new Double[n];
        m.PC5 = new Double[n];
        m.P5 = new Double[n];
        m.PD = new Double[n];
        m.R = new String[n];
        Double[] Fb = new Double[n];
        for (int i = 0; i < n; i++) { m.F[i] = days.get(i).net; m.P[i] = days.get(i).close; Fb[i] = m.F[i]; }
        for (int i = 0; i < n; i++) {
            if (i >= 4) m.S5[i] = m.F[i - 4] + m.F[i - 3] + m.F[i - 2] + m.F[i - 1] + m.F[i];
            if (i >= 5 && m.P[i - 5] > 0) m.PC5[i] = (m.P[i] / m.P[i - 5] - 1) * 100;
        }
        for (int i = 0; i < n; i++) { m.P5[i] = pctile(m.S5, i); m.PD[i] = pctile(Fb, i); }
        for (int i = 0; i < n; i++) m.R[i] = read(m.S5[i], m.PC5[i], m.P5[i]);
        return m;
    }

    /** sessions back to an equal or bigger day in the same direction; -1 = none on record */
    static int sinceBigger(double[] F, int i) {
        for (int j = i - 1; j >= 0; j--) if (F[i] < 0 ? F[j] <= F[i] : F[j] >= F[i]) return i - j;
        return -1;
    }

    /** {up, n} for BTC higher k sessions after each separate occasion of a read (same grouping as the tab) */
    static int[] track(Metrics m, String code, int k) {
        int up = 0, cnt = 0, last = -99;
        for (int i = 0; i < m.R.length; i++) {
            if (!m.R[i].equals(code)) continue;
            boolean fresh = i - last > 5;
            last = i;
            if (!fresh || i + k >= m.P.length) continue;
            cnt++;
            if (m.P[i + k] > m.P[i]) up++;
        }
        return new int[]{up, cnt};
    }

    static String fmtM(double v) {
        double a = Math.abs(v);
        String s = v >= 0 ? "+" : "−";
        if (a >= 1000) return s + String.format(java.util.Locale.UK, "$%.2fB", a / 1000);
        if (a >= 100) return s + String.format(java.util.Locale.UK, "$%.0fM", a);
        return s + String.format(java.util.Locale.UK, "$%.1fM", a);
    }

    /** {title, text} of the notification for the latest session */
    static String[] summary(Metrics m) {
        int i = m.days.size() - 1;
        Day d = m.days.get(i);
        String code = m.R[i];
        String[] inf = info(code);
        StringBuilder t = new StringBuilder();
        t.append(fmtM(d.net));
        int sb = sinceBigger(m.F, i);
        if (sb < 0) t.append(d.net < 0 ? " (biggest outflow on record)" : " (biggest inflow on record)");
        else if (sb >= 20) t.append(d.net < 0 ? " (biggest outflow in " + sb + " sessions)" : " (biggest inflow in " + sb + " sessions)");
        List<Map.Entry<String, Double>> top = new ArrayList<>(d.funds.entrySet());
        top.removeIf(e -> e.getValue() == 0);
        Collections.sort(top, (a, b) -> Double.compare(Math.abs(b.getValue()), Math.abs(a.getValue())));
        if (!top.isEmpty()) {
            t.append(" · ");
            for (int k = 0; k < Math.min(2, top.size()); k++) t.append(k > 0 ? ", " : "").append(top.get(k).getKey()).append(' ').append(fmtM(top.get(k).getValue()));
        }
        if (m.S5[i] != null && m.PC5[i] != null)
            t.append(" · last 5 sessions ").append(fmtM(m.S5[i])).append(String.format(java.util.Locale.UK, ", BTC %s%.1f%%", m.PC5[i] >= 0 ? "+" : "−", Math.abs(m.PC5[i])));
        t.append(". ").append(inf[1]).append(' ').append(inf[0]).append(": ").append(meaning(code));
        if (!"none".equals(code)) {
            int[] r = track(m, code, 10);
            if (r[1] > 0) t.append(" Past record: BTC higher 10 sessions later ").append(r[0]).append(" of ").append(r[1]).append(" times.");
        }
        String title = "🏦 BTC ETFs " + fmtM(d.net) + " · " + inf[0];
        return new String[]{title, t.toString(), d.date, code};
    }
}
