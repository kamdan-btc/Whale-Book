package uk.kamil.whalebook;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.PowerManager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * Runs in the background (even with the screen locked) and checks the
 * BTC, ETH and SOL markets the user ticked, on a timer. Sends a notification when:
 *  - a large market order executes (Binance spot/perp, Coinbase)
 *  - buying or selling suddenly speeds up versus the past hour
 *  - a whale wall appears, is pulled, or is hit by price
 */
public class WhaleService extends Service {
    private static final String CH_STATUS = "status";
    private static final String CH_ALERT = "alerts";      // grouped summaries
    private static final String CH_SPOT = "spot_alerts";
    private static final String CH_PERP = "perp_alerts";
    private static final String CH_SIG = "signal_alerts";
    private static final int STATUS_ID = 1;

    private HandlerThread thread;
    private Handler handler;
    private PowerManager.WakeLock wakeLock;
    private NotificationManager nm;
    private int nextAlertId = 100;

    // exchange symbols per coin: Binance, Coinbase, Kraken, OKX, Bybit, Bitfinex spot, Bitfinex perp,
    // Hyperliquid coin, Hyperliquid book grouping (significant figures), Binance coin-margined perp
    private static final String[] COINS = {"BTC", "ETH", "SOL"};
    private static final Map<String, String[]> SYM = new HashMap<>();
    static {
        SYM.put("BTC", new String[]{"BTCUSDT", "BTC-USD", "XBTUSD", "BTC-USDT", "BTCUSDT", "tBTCUSD", "tBTCF0:USTF0", "BTC", "3", "BTCUSD_PERP"});
        SYM.put("ETH", new String[]{"ETHUSDT", "ETH-USD", "ETHUSD", "ETH-USDT", "ETHUSDT", "tETHUSD", "tETHF0:USTF0", "ETH", "3", "ETHUSD_PERP"});
        SYM.put("SOL", new String[]{"SOLUSDT", "SOL-USD", "SOLUSD", "SOL-USDT", "SOLUSDT", "tSOLUSD", "tSOLF0:USTF0", "SOL", "4", "SOLUSD_PERP"});
    }
    // whale wall, big spot order, big perp order, spot 5-min net, perp 5-min net
    private static final Map<String, Double> CT_DEFAULT = new HashMap<>(); // OKX perp contract size in coins
    static {
        CT_DEFAULT.put("BTC", 0.01);
        CT_DEFAULT.put("ETH", 0.1);
        CT_DEFAULT.put("SOL", 1.0);
    }
    private final Map<String, Double> ctVals = new HashMap<>();
    private static final Map<String, double[]> DEFAULTS = new HashMap<>();
    static {
        DEFAULTS.put("BTC", new double[]{50, 10, 25, 30, 100});
        DEFAULTS.put("ETH", new double[]{1500, 300, 800, 1000, 3000});
        DEFAULTS.put("SOL", new double[]{40000, 8000, 20000, 25000, 80000});
    }

    /** What the watcher remembers about one coin between checks. */
    private static final class CoinState {
        boolean first = true;
        long lastSpotId = -1, lastPerpId = -1, lastCbId = -1;
        long lastBfxSpotId = -1, lastBfxPerpId = -1, lastBfxPoll = 0;
        final Map<String, Long> marks = new HashMap<>(); // last trade id / time seen, per exchange feed
        final long[] lastPace = new long[4]; // spot buy, spot sell, perp buy, perp sell
        String pendingSig = null;            // a signal must show on two checks in a row
        final Map<String, Long> lastSig = new HashMap<>();
        final Map<String, Wall> walls = new HashMap<>();
    }
    private final Map<String, CoinState> states = new HashMap<>();

    // the coin being checked right now
    private String coin = "BTC";
    private String[] sym = SYM.get("BTC");
    private CoinState st;
    private boolean first;
    private int alertsThisCheck = 0;
    private boolean spotOn = true, perpOn = true, sigOn = true;
    // last hour of 1-minute data from checkFlow, [0] = spot, [1] = perp
    private final double[][] flowBuy = new double[2][], flowSell = new double[2][], flowClose = new double[2][];
    private final List<String> overflow = new ArrayList<>();

    private static final class Wall {
        String venue, side;
        double price, qty;
        int seen;
        boolean alerted;
    }

    public static void start(Context c) {
        Intent i = new Intent(c, WhaleService.class);
        if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i);
        else c.startService(i);
    }

    private final Runnable loop = new Runnable() {
        @Override
        public void run() {
            int interval = 60;
            try {
                interval = Math.max(20, Prefs.settings(WhaleService.this).optInt("interval", 60));
                check();
            } catch (Throwable t) {
                updateStatus("Connection problem, retrying…");
            }
            if (handler != null) handler.postDelayed(this, interval * 1000L);
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel st = new NotificationChannel(CH_STATUS, "Running status", NotificationManager.IMPORTANCE_LOW);
            st.setShowBadge(false);
            nm.createNotificationChannel(st);
            NotificationChannel al = new NotificationChannel(CH_ALERT, "Grouped whale alerts", NotificationManager.IMPORTANCE_HIGH);
            al.enableVibration(true);
            nm.createNotificationChannel(al);
            NotificationChannel sp = new NotificationChannel(CH_SPOT, "Spot alerts", NotificationManager.IMPORTANCE_HIGH);
            sp.enableVibration(true);
            nm.createNotificationChannel(sp);
            NotificationChannel pp = new NotificationChannel(CH_PERP, "Perp alerts", NotificationManager.IMPORTANCE_HIGH);
            pp.enableVibration(true);
            nm.createNotificationChannel(pp);
            NotificationChannel sg = new NotificationChannel(CH_SIG, "Spot vs perp signals", NotificationManager.IMPORTANCE_HIGH);
            sg.enableVibration(true);
            nm.createNotificationChannel(sg);
        }
        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "whalebook:check");
        wakeLock.setReferenceCounted(false);
        wakeLock.acquire();
        thread = new HandlerThread("whale-check");
        thread.start();
        handler = new Handler(thread.getLooper());
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Notification n = statusNotification("Starting…");
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(STATUS_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
        } else {
            startForeground(STATUS_ID, n);
        }
        if (!Prefs.enabled(this)) {
            stopSelf();
            return START_NOT_STICKY;
        }
        handler.removeCallbacks(loop);
        handler.post(loop);
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        if (handler != null) handler.removeCallbacksAndMessages(null);
        if (thread != null) thread.quitSafely();
        handler = null;
        if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    // ------------------------------------------------------------------ checks

    private void check() throws Exception {
        JSONObject s = Prefs.settings(this);
        double accel = s.optDouble("accel", 3);
        double range = s.optDouble("range", 2) / 100.0;
        spotOn = s.optBoolean("spotOn", true);
        perpOn = s.optBoolean("perpOn", true);
        sigOn = s.optBoolean("sigOn", true);
        JSONObject coins = s.optJSONObject("coins");
        alertsThisCheck = 0;
        overflow.clear();

        List<String> status = new ArrayList<>();
        for (String c : COINS) {
            double[] d = DEFAULTS.get(c);
            boolean on;
            JSONObject o;
            if (coins != null) {
                o = coins.optJSONObject(c);
                on = o != null && o.optBoolean("on", false);
            } else { // settings saved by version 1.1 (BTC only)
                o = s;
                on = "BTC".equals(c);
            }
            if (o == null) o = new JSONObject();
            double whale = o.optDouble("whale", d[0]);
            double execSpot = o.optDouble("execSpot", d[1]);
            double execPerp = o.optDouble("execPerp", o.optDouble("exec", d[2]));   // "exec" = older versions
            double netSpot = o.optDouble("netSpot", d[3]);
            double netPerp = o.optDouble("netPerp", o.optDouble("minNet", d[4]));
            if (!on) {
                states.remove(c); // start fresh if it is switched back on later
                continue;
            }
            coin = c;
            sym = SYM.get(c);
            st = states.get(c);
            if (st == null) { st = new CoinState(); states.put(c, st); }
            first = st.first;

            String line = "";
            try {
                line = checkFlow(accel, netSpot, netPerp);
            } catch (Exception ignored) {
            }
            try {
                if (sigOn) checkSignal();
            } catch (Exception ignored) {
            }
            try {
                checkExecutions(execSpot, execPerp);
            } catch (Exception ignored) {
            }
            try {
                checkWalls(whale, range);
            } catch (Exception ignored) {
            }
            st.first = false;
            status.add(line.isEmpty() ? c : line);
        }
        if (!overflow.isEmpty()) {
            show(CH_ALERT, "🐋 " + overflow.size() + " more whale events", String.join(" · ", overflow));
        }
        String time = String.format(Locale.UK, "%tR", Calendar.getInstance());
        String none = status.isEmpty() ? "No coins ticked" : (!spotOn && !perpOn && !sigOn ? "Nothing ticked under Markets" : null);
        updateStatus((none != null ? none : String.join(" · ", status)) + " · " + time);
    }

    /**
     * Pace alerts and today's totals, kept separate for Binance spot and Binance perps.
     * Spot = coins actually bought or sold; perps = leveraged positions.
     */
    private String checkFlow(double accel, double netSpot, double netPerp) {
        String[] label = {"SPOT", "PERP"};
        // spot: Binance USDT + USDC + FDUSD pairs; perps: Binance USDT + USDC + coin-margined
        String SP = "https://api.binance.com/api/v3/klines?symbol=", FP = "https://fapi.binance.com/fapi/v1/klines?symbol=", DP = "https://dapi.binance.com/dapi/v1/klines?symbol=";
        String usdc = sym[0].replace("USDT", "USDC"), fdusd = sym[0].replace("USDT", "FDUSD");
        String[][] feeds = {{SP + sym[0], SP + usdc, SP + fdusd}, {FP + sym[0], FP + usdc, DP + sym[9]}};
        String[] base = {SP, FP};
        double[] thr = {netSpot, netPerp};
        boolean[] on = {spotOn, perpOn};
        double price = 0;
        long now = System.currentTimeMillis();
        flowBuy[0] = flowBuy[1] = flowSell[0] = flowSell[1] = flowClose[0] = flowClose[1] = null;
        for (int m = 0; m < 2; m++) {
            if (!on[m] && !sigOn) continue;
            double[] buy = new double[60], sell = new double[60], close = new double[60];
            boolean main = false;
            long lastOpen = 0;
            for (int f = 0; f < feeds[m].length; f++) {
                boolean coinM = feeds[m][f].startsWith(DP);
                try {
                    JSONArray k = new JSONArray(get(feeds[m][f] + "&interval=1m&limit=60"));
                    if (k.length() == 0) continue;
                    long open = k.getJSONArray(k.length() - 1).getLong(0);
                    if (f == 0) lastOpen = open;
                    else if (!main || open != lastOpen) continue; // only add feeds that line up with the main one
                    int off = 60 - k.length();
                    for (int i = 0; i < k.length(); i++) {
                        JSONArray c = k.getJSONArray(i);
                        // coin-margined candles count contracts in columns 5 and 9; their coin amounts are in 7 and 10
                        double vol = Double.parseDouble(c.getString(coinM ? 7 : 5));
                        double b = Double.parseDouble(c.getString(coinM ? 10 : 9));
                        buy[off + i] += b;
                        sell[off + i] += vol - b;
                        if (f == 0) close[off + i] = Double.parseDouble(c.getString(4));
                    }
                    if (f == 0) {
                        main = true;
                        if (m == 0 || price == 0) price = close[59];
                    }
                } catch (Exception ignored) {
                }
            }
            if (!main) continue;
            flowBuy[m] = buy;
            flowSell[m] = sell;
            flowClose[m] = close;
            if (!on[m]) continue; // fetched only for the spot-vs-perp signal
            double b5 = 0, s5 = 0, bBase = 0, sBase = 0;
            for (int i = 55; i < 60; i++) { b5 += buy[i]; s5 += sell[i]; }
            for (int i = 0; i < 55; i++) { bBase += buy[i]; sBase += sell[i]; }
            double avgB = bBase / 11.0, avgS = sBase / 11.0; // average per 5 minutes
            double net = b5 - s5;
            String market = m == 0 ? "spot" : "perp";
            if (!first && avgS > 0 && s5 / avgS >= accel && -net >= thr[m] && now - st.lastPace[m * 2 + 1] > 10 * 60_000) {
                st.lastPace[m * 2 + 1] = now;
                alert(market, "sell", String.format(Locale.UK, "⚠ %s %s selling accelerating: %.1f× normal", coin, label[m].toLowerCase(Locale.UK), s5 / avgS),
                        String.format(Locale.UK, "Binance %s (all pairs) · net %s %s in the last 5 min · price %s", market, fmtSigned(net), coin, fmtPrice(price)), false);
            }
            if (!first && avgB > 0 && b5 / avgB >= accel && net >= thr[m] && now - st.lastPace[m * 2] > 10 * 60_000) {
                st.lastPace[m * 2] = now;
                alert(market, "buy", String.format(Locale.UK, "⚠ %s %s buying accelerating: %.1f× normal", coin, label[m].toLowerCase(Locale.UK), b5 / avgB),
                        String.format(Locale.UK, "Binance %s (all pairs) · net %s %s in the last 5 min · price %s", market, fmtSigned(net), coin, fmtPrice(price)), false);
            }
        }

        // today's net since local midnight, per market (5-minute candles)
        Calendar mid = Calendar.getInstance();
        mid.set(Calendar.HOUR_OF_DAY, 0);
        mid.set(Calendar.MINUTE, 0);
        mid.set(Calendar.SECOND, 0);
        mid.set(Calendar.MILLISECOND, 0);
        long start = mid.getTimeInMillis();
        StringBuilder out = new StringBuilder(coin);
        if (price > 0) out.append(" ").append(fmtPrice(price));
        // Same sources as the dashboard's daily chart: every Binance pair for that market + OKX (all pairs).
        for (int m = 0; m < 2; m++) {
            if (!on[m]) continue;
            double net = 0;
            boolean main = false;
            for (int f = 0; f < feeds[m].length; f++) {
                boolean coinM = feeds[m][f].startsWith(DP);
                try {
                    JSONArray k = new JSONArray(get(feeds[m][f] + "&interval=5m&limit=288&startTime=" + start));
                    for (int i = 0; i < k.length(); i++) {
                        JSONArray c = k.getJSONArray(i);
                        double vol = Double.parseDouble(c.getString(coinM ? 7 : 5));
                        double b = Double.parseDouble(c.getString(coinM ? 10 : 9));
                        net += b - (vol - b);
                    }
                    if (f == 0) main = true;
                } catch (Exception ignored) {
                }
            }
            if (!main) continue;
            double[] ok = okxTaker(m == 0 ? "SPOT" : "CONTRACTS", price, start);
            if (ok != null) net += ok[0] - ok[1];
            out.append(m == 0 ? " · spot " : " · perp ").append(fmtSigned(net));
        }
        return out.toString();
    }

    /**
     * Spot vs perps over the last hour. Same rules as the dashboard's "who is driving?" panel.
     * Alerts only on the readings worth acting on, after two checks in a row, at most once an hour each.
     */
    private void checkSignal() {
        if (flowBuy[0] == null || flowBuy[1] == null) return;
        double sB = 0, sS = 0, pB = 0, pS = 0;
        for (int i = 0; i < 60; i++) { sB += flowBuy[0][i]; sS += flowSell[0][i]; pB += flowBuy[1][i]; pS += flowSell[1][i]; }
        if (sB + sS <= 0 || pB + pS <= 0) return;
        double priceNow = flowClose[0][59];
        double[] okSpot = okxTaker("SPOT", priceNow), okPerp = okxTaker("CONTRACTS", priceNow);
        if (okSpot != null) { sB += okSpot[0]; sS += okSpot[1]; }
        if (okPerp != null) { pB += okPerp[0]; pS += okPerp[1]; }
        double sImb = (sB - sS) / (sB + sS), pImb = (pB - pS) / (pB + pS);
        double[] cl = flowClose[0];
        double p0 = 0, p1 = cl[59];
        for (double v : cl) if (v > 0) { p0 = v; break; }
        if (p0 <= 0 || p1 <= 0) return;
        double dP = (p1 - p0) / p0 * 100;
        // open interest over the hour, in coins, added up across Binance, Bybit and OKX
        double oiA = 0, oiB = 0;
        try {
            JSONArray oi = new JSONArray(get("https://fapi.binance.com/futures/data/openInterestHist?symbol=" + sym[0] + "&period=5m&limit=13"));
            if (oi.length() >= 2) {
                double o0 = Double.parseDouble(oi.getJSONObject(0).getString("sumOpenInterest"));
                double o1 = Double.parseDouble(oi.getJSONObject(oi.length() - 1).getString("sumOpenInterest"));
                if (o0 > 0) { oiA += o0; oiB += o1; }
            }
        } catch (Exception ignored) {
        }
        try {
            JSONArray l = new JSONObject(get("https://api.bybit.com/v5/market/open-interest?category=linear&symbol=" + sym[4] + "&intervalTime=5min&limit=13"))
                    .getJSONObject("result").getJSONArray("list"); // newest first
            if (l.length() >= 2) {
                double o1 = Double.parseDouble(l.getJSONObject(0).getString("openInterest"));
                double o0 = Double.parseDouble(l.getJSONObject(l.length() - 1).getString("openInterest"));
                if (o0 > 0) { oiA += o0; oiB += o1; }
            }
        } catch (Exception ignored) {
        }
        double[] okOI = okxOpenInterest(priceNow);
        if (okOI != null) { oiA += okOI[0]; oiB += okOI[1]; }
        Double dOI = oiA > 0 ? (oiB - oiA) / oiA * 100 : null;
        Double funding = null;
        try {
            funding = Double.parseDouble(new JSONObject(get("https://fapi.binance.com/fapi/v1/premiumIndex?symbol=" + sym[0])).getString("lastFundingRate"));
        } catch (Exception ignored) {
        }
        String[] r = classify(sImb, pImb, dP, dOI);
        String code = r[0];
        boolean alertable = code.equals("distribution") || code.equals("absorption") || code.equals("short_squeeze")
                || code.equals("leverage_long") || code.equals("long_flush") || code.equals("shorts_piling");
        if (!alertable) { st.pendingSig = null; return; }
        boolean confirmed = code.equals(st.pendingSig);
        st.pendingSig = code;
        if (!confirmed || first) return;
        long now = System.currentTimeMillis();
        Long last = st.lastSig.get(code);
        if (last != null && now - last < 60 * 60_000) return;
        st.lastSig.put(code, now);
        StringBuilder text = new StringBuilder(r[2]);
        text.append(String.format(Locale.UK, " Last hour: spot %+.1f%%, perps %+.1f%% net, price %+.2f%%", sImb * 100, pImb * 100, dP));
        if (dOI != null) text.append(String.format(Locale.UK, ", open interest %+.2f%%", dOI));
        text.append(".");
        if (funding != null && funding >= 0.0003) text.append(" Funding is high: longs crowded.");
        if (funding != null && funding <= -0.0001) text.append(" Funding is negative: shorts crowded.");
        alert("signal", "signal", r[1] + " · " + coin, text.toString(), false);
    }

    /** Returns {code, title, one-line meaning}. Mirrors classify() in the dashboard. */
    private static String[] classify(double sImb, double pImb, double dP, Double dOI) {
        final double I = 0.03, P = 0.3, O = 0.5;
        boolean sBuy = sImb >= I, sSell = sImb <= -I, pBuy = pImb >= I, pSell = pImb <= -I;
        boolean up = dP >= P, dn = dP <= -P;
        boolean oiUp = dOI != null && dOI >= O, oiDn = dOI != null && dOI <= -O;
        if (pBuy && sSell) return new String[]{"distribution", "⚠ Spot selling into perp buying",
                oiUp ? "Spot holders are selling to new leveraged longs: possible exit liquidity. If price stalls, longs can be flushed."
                     : "Spot holders are selling while perp traders buy. If price stalls, those longs are exposed."};
        if (sBuy && pSell) return new String[]{"absorption", "🧲 Spot buying while perps sell",
                oiUp ? "Real buyers are absorbing new leveraged shorts. Squeeze risk upward if price holds."
                     : "Real buyers are absorbing perp selling. Usually supportive for price."};
        if (sBuy && pBuy) return new String[]{"broad_buy", "✅ Spot and perps both buying", "Buyers agree across both markets."};
        if (sSell && pSell) return new String[]{"broad_sell", "🔻 Spot and perps both selling", "Sellers agree across both markets."};
        if (pBuy && up) {
            if (oiDn) return new String[]{"short_squeeze", "🩳 Short squeeze", "Price rising while open interest falls: shorts closing, not new demand. Often runs out once shorts are done."};
            return new String[]{"leverage_long", "🎢 Perp-led rise", "Price rising on perp buying with little spot support. Leverage-led moves fade more often."};
        }
        if (sBuy && up) return new String[]{"spot_rally", "🟢 Spot-led rise", "Real coins are being bought."};
        if (pSell && dn) {
            if (oiDn) return new String[]{"long_flush", "🌊 Long flush", "Price falling while open interest drops: longs closing or being liquidated. Flushes often end sharply."};
            if (oiUp) return new String[]{"shorts_piling", "🐻 Shorts piling in", "Price falling while open interest rises: new shorts opening. Squeeze risk if spot holds firm."};
            return new String[]{"perp_drop", "🔻 Perp-led drop", "Price falling on perp selling."};
        }
        if (sSell && dn) return new String[]{"spot_drop", "🔴 Spot-led drop", "Real coins are being sold."};
        return new String[]{"mixed", "No clear signal", ""};
    }

    /**
     * OKX taker buy/sell over the last hour for all its spot pairs or all its derivatives, as {buy, sell} in coins.
     * OKX doesn't say whether these figures are coins or dollars, so compare them with OKX's own coin volume first.
     */
    private double[] okxTaker(String kind, double price) {
        return okxTaker(kind, price, System.currentTimeMillis() - 60 * 60_000L);
    }

    private double[] okxTaker(String kind, double price, long since) {
        try {
            JSONArray rows = new JSONObject(get("https://www.okx.com/api/v5/rubik/stat/taker-volume?ccy=" + coin + "&instType=" + kind + "&period=5m&begin=" + since)).getJSONArray("data");
            String inst = "SPOT".equals(kind) ? sym[3] : sym[3] + "-SWAP";
            // up to 300 five-minute candles: enough to price every bar of the day
            JSONArray cd = new JSONObject(get("https://www.okx.com/api/v5/market/candles?instId=" + inst + "&bar=5m&limit=300")).getJSONArray("data");
            Map<Long, Double> coinVol = new HashMap<>(), closeAt = new HashMap<>();
            double latest = price;
            for (int i = 0; i < cd.length(); i++) {
                JSONArray k = cd.getJSONArray(i);
                long t = Long.parseLong(k.getString(0));
                coinVol.put(t, Double.parseDouble(k.getString("SPOT".equals(kind) ? 5 : 6)));
                closeAt.put(t, Double.parseDouble(k.getString(4)));
                if (i == 0) latest = Double.parseDouble(k.getString(4)); // newest first
            }
            double buy = 0, sell = 0, matched = 0, ref = 0;
            List<double[]> bars = new ArrayList<>(); // {time, sell, buy}
            for (int i = 0; i < rows.length(); i++) {
                JSONArray r = rows.getJSONArray(i);
                long t = Long.parseLong(r.getString(0));
                if (t < since) continue;
                double sv = Double.parseDouble(r.getString(1)), bv = Double.parseDouble(r.getString(2));
                bars.add(new double[]{t, sv, bv});
                Double v = coinVol.get(t);
                if (v != null) { matched += sv + bv; ref += v; }
            }
            if (bars.isEmpty()) return null;
            boolean dollars = ref > 0 && latest > 0 && matched / ref > latest * 0.2;
            for (double[] b : bars) {
                double px = 1;
                if (dollars) { Double c = closeAt.get((long) b[0]); px = c != null ? c : latest; }
                sell += b[1] / px;
                buy += b[2] / px;
            }
            return new double[]{buy, sell};
        } catch (Exception e) {
            return null;
        }
    }

    /** OKX open interest (all derivatives) an hour ago and now, in coins: {then, now}. */
    private double[] okxOpenInterest(double price) {
        try {
            long since = System.currentTimeMillis() - 65 * 60_000L;
            JSONArray rows = new JSONObject(get("https://www.okx.com/api/v5/rubik/stat/contracts/open-interest-volume?ccy=" + coin + "&period=5m&begin=" + since)).getJSONArray("data");
            long t0 = Long.MAX_VALUE, t1 = 0;
            double v0 = 0, v1 = 0;
            for (int i = 0; i < rows.length(); i++) {
                JSONArray r = rows.getJSONArray(i);
                long t = Long.parseLong(r.getString(0));
                double v = Double.parseDouble(r.getString(1));
                if (t < t0) { t0 = t; v0 = v; }
                if (t > t1) { t1 = t; v1 = v; }
            }
            if (t1 <= t0 || v0 <= 0) return null;
            double one = Double.parseDouble(new JSONObject(get("https://www.okx.com/api/v5/public/open-interest?instType=SWAP&instId=" + sym[3] + "-SWAP"))
                    .getJSONArray("data").getJSONObject(0).getString("oiCcy"));
            if (one > 0 && price > 0 && v1 / one > price * 0.2) { v0 /= price; v1 /= price; } // figures were in dollars
            return new double[]{v0, v1};
        } catch (Exception e) {
            return null;
        }
    }

    private double ctVal() {
        Double v = ctVals.get(coin);
        if (v != null) return v;
        try {
            v = Double.parseDouble(new JSONObject(get("https://www.okx.com/api/v5/public/instruments?instType=SWAP&instId=" + sym[3] + "-SWAP"))
                    .getJSONArray("data").getJSONObject(0).getString("ctVal"));
            if (v > 0) { ctVals.put(coin, v); return v; }
        } catch (Exception ignored) {
        }
        return CT_DEFAULT.get(coin);
    }

    /** Large market orders since the previous check. */
    private void checkExecutions(double execSpot, double execPerp) throws Exception {
        String usdc = sym[0].replace("USDT", "USDC"), fdusd = sym[0].replace("USDT", "FDUSD");
        if (perpOn) {
            st.lastPerpId = binanceTrades("https://fapi.binance.com/fapi/v1/aggTrades?symbol=" + sym[0], st.lastPerpId, execPerp, "Binance perp", "perp");
            mark("bnf-usdc", binanceTrades("https://fapi.binance.com/fapi/v1/aggTrades?symbol=" + usdc, markOf("bnf-usdc"), execPerp, "Binance perp (USDC)", "perp"));
            okxTrades(sym[3] + "-SWAP", "okxf", execPerp, "OKX perp", "perp", ctVal());
            bybitTrades("linear", "byf", execPerp, "Bybit perp", "perp");
            hyperTrades(execPerp);
        } else {
            st.lastPerpId = -1;
            for (String k : new String[]{"bnf-usdc", "okxf", "byf", "hyper"}) st.marks.remove(k);
        }
        if (spotOn) {
            mark("bn-usdc", binanceTrades("https://api.binance.com/api/v3/aggTrades?symbol=" + usdc, markOf("bn-usdc"), execSpot, "Binance spot (USDC)", "spot"));
            mark("bn-fdusd", binanceTrades("https://api.binance.com/api/v3/aggTrades?symbol=" + fdusd, markOf("bn-fdusd"), execSpot, "Binance spot (FDUSD)", "spot"));
            okxTrades(sym[3], "okx", execSpot, "OKX spot", "spot", 1);
            bybitTrades("spot", "bys", execSpot, "Bybit spot", "spot");
            krakenTrades(execSpot);
        } else {
            for (String k : new String[]{"bn-usdc", "bn-fdusd", "okx", "bys", "kraken"}) st.marks.remove(k);
        }
        // Bitfinex allows 15 trade requests a minute across everything, so poll it at most once a minute per coin
        long now = System.currentTimeMillis();
        if (now - st.lastBfxPoll >= 55_000) {
            st.lastBfxPoll = now;
            if (perpOn) st.lastBfxPerpId = bitfinexTrades(sym[6], st.lastBfxPerpId, execPerp, "Bitfinex perp", "perp");
            else st.lastBfxPerpId = -1;
            if (spotOn) st.lastBfxSpotId = bitfinexTrades(sym[5], st.lastBfxSpotId, execSpot, "Bitfinex spot", "spot");
            else st.lastBfxSpotId = -1;
        }
        if (!spotOn) { st.lastSpotId = -1; st.lastCbId = -1; return; }
        st.lastSpotId = binanceTrades("https://api.binance.com/api/v3/aggTrades?symbol=" + sym[0], st.lastSpotId, execSpot, "Binance spot", "spot");
        double exec = execSpot;
        try {
            JSONArray t = new JSONArray(get("https://api.exchange.coinbase.com/products/" + sym[1] + "/trades?limit=1000"));
            long maxId = st.lastCbId;
            for (int i = 0; i < t.length(); i++) {
                JSONObject o = t.getJSONObject(i);
                long id = o.getLong("trade_id");
                if (id > maxId) maxId = id;
                if (st.lastCbId < 0 || id <= st.lastCbId) continue;
                double q = Double.parseDouble(o.getString("size"));
                if (q < exec) continue;
                double p = Double.parseDouble(o.getString("price"));
                // Coinbase reports the maker side; the market order is the opposite
                boolean buy = "sell".equals(o.getString("side"));
                executionAlert(buy, q, p, "Coinbase", "spot");
            }
            st.lastCbId = maxId;
        } catch (Exception ignored) {
        }
    }

    private long markOf(String key) {
        Long v = st.marks.get(key);
        return v == null ? -1 : v;
    }

    private void mark(String key, long v) {
        st.marks.put(key, v);
    }

    /** OKX trades: side is the market order's side; perp sizes are contracts (times ctVal = coins). */
    private void okxTrades(String instId, String key, double exec, String venue, String market, double mult) {
        try {
            JSONArray t = new JSONObject(get("https://www.okx.com/api/v5/market/trades?instId=" + instId + "&limit=500")).getJSONArray("data");
            long last = markOf(key), max = last;
            for (int i = 0; i < t.length(); i++) {
                JSONObject o = t.getJSONObject(i);
                long id = Long.parseLong(o.getString("tradeId"));
                if (id > max) max = id;
                if (last < 0 || id <= last) continue; // first poll only sets the starting point
                double q = Double.parseDouble(o.getString("sz")) * mult;
                if (q < exec) continue;
                executionAlert("buy".equals(o.getString("side")), q, Double.parseDouble(o.getString("px")), venue, market);
            }
            mark(key, max);
        } catch (Exception ignored) {
        }
    }

    /** Bybit trades: side is the market order's side ("Buy"/"Sell"). Tracked by time. Spot returns at most 60. */
    private void bybitTrades(String category, String key, double exec, String venue, String market) {
        try {
            JSONArray t = new JSONObject(get("https://api.bybit.com/v5/market/recent-trade?category=" + category + "&symbol=" + sym[4] + "&limit=" + ("spot".equals(category) ? 60 : 1000)))
                    .getJSONObject("result").getJSONArray("list");
            long last = markOf(key), max = last;
            for (int i = 0; i < t.length(); i++) {
                JSONObject o = t.getJSONObject(i);
                long time = Long.parseLong(o.getString("time"));
                if (time > max) max = time;
                if (last < 0 || time <= last) continue;
                double q = Double.parseDouble(o.getString("size"));
                if (q < exec) continue;
                executionAlert("Buy".equals(o.getString("side")), q, Double.parseDouble(o.getString("price")), venue, market);
            }
            mark(key, max);
        } catch (Exception ignored) {
        }
    }

    /** Kraken trades: [price, volume, time, "b"/"s", ...]; "last" is passed back as since= next time. */
    private void krakenTrades(double exec) {
        try {
            long last = markOf("kraken");
            String url = "https://api.kraken.com/0/public/Trades?pair=" + sym[2] + (last > 0 ? "&since=" + last : "&count=1");
            JSONObject r = new JSONObject(get(url)).getJSONObject("result");
            long next = Long.parseLong(r.getString("last"));
            if (last > 0) {
                java.util.Iterator<String> keys = r.keys();
                while (keys.hasNext()) {
                    String k = keys.next();
                    if ("last".equals(k)) continue;
                    JSONArray t = r.getJSONArray(k);
                    for (int i = 0; i < t.length(); i++) {
                        JSONArray x = t.getJSONArray(i);
                        double q = Double.parseDouble(x.getString(1));
                        if (q < exec) continue;
                        executionAlert("b".equals(x.getString(3)), q, Double.parseDouble(x.getString(0)), "Kraken", "spot");
                    }
                }
            }
            mark("kraken", next);
        } catch (Exception ignored) {
        }
    }

    /** Hyperliquid recent trades: side "B" = market buy, "A" = market sell. Tracked by time. */
    private void hyperTrades(double exec) {
        try {
            JSONArray t = new JSONArray(post("https://api.hyperliquid.xyz/info", "{\"type\":\"recentTrades\",\"coin\":\"" + sym[7] + "\"}"));
            long last = markOf("hyper"), max = last;
            for (int i = 0; i < t.length(); i++) {
                JSONObject o = t.getJSONObject(i);
                long time = o.getLong("time");
                if (time > max) max = time;
                if (last < 0 || time <= last) continue;
                double q = Double.parseDouble(o.getString("sz"));
                if (q < exec) continue;
                executionAlert("B".equals(o.getString("side")), q, Double.parseDouble(o.getString("px")), "Hyperliquid perp", "perp");
            }
            mark("hyper", max);
        } catch (Exception ignored) {
        }
    }

    /** Bitfinex trades are [id, time, amount, price]; amount > 0 is a market buy, < 0 a market sell. */
    private long bitfinexTrades(String symbol, long lastId, double exec, String venue, String market) {
        try {
            JSONArray t = new JSONArray(get("https://api-pub.bitfinex.com/v2/trades/" + symbol + "/hist?limit=1000&sort=-1"));
            long maxId = lastId;
            for (int i = 0; i < t.length(); i++) {
                JSONArray r = t.getJSONArray(i);
                long id = r.getLong(0);
                if (id > maxId) maxId = id;
                if (lastId < 0 || id <= lastId) continue; // first poll only sets the starting point
                double amt = r.getDouble(2), q = Math.abs(amt);
                if (q < exec) continue;
                executionAlert(amt > 0, q, r.getDouble(3), venue, market);
            }
            return maxId;
        } catch (Exception e) {
            return lastId;
        }
    }

    private long binanceTrades(String base, long lastId, double exec, String venue, String market) {
        try {
            if (lastId < 0) {
                JSONArray t = new JSONArray(get(base + "&limit=1"));
                return t.length() > 0 ? t.getJSONObject(0).getLong("a") : -1;
            }
            long id = lastId;
            for (int page = 0; page < 4; page++) {
                JSONArray t = new JSONArray(get(base + "&limit=1000&fromId=" + (id + 1)));
                for (int i = 0; i < t.length(); i++) {
                    JSONObject o = t.getJSONObject(i);
                    id = Math.max(id, o.getLong("a"));
                    double q = Double.parseDouble(o.getString("q"));
                    if (q < exec) continue;
                    double p = Double.parseDouble(o.getString("p"));
                    boolean buy = !o.getBoolean("m"); // m = buyer was maker → a market sell
                    executionAlert(buy, q, p, venue, market);
                }
                if (t.length() < 1000) break;
            }
            return id;
        } catch (Exception e) {
            return lastId;
        }
    }

    private void executionAlert(boolean buy, double q, double p, String venue, String market) {
        String title = String.format(Locale.UK, "🐋 %s %s market %s", fmtQty(q), coin, buy ? "BUY" : "SELL");
        String text = String.format(Locale.UK, "%s at %s (%s)", venue, fmtPrice(p), fmtUsd(q * p));
        alert(market, buy ? "buy" : "sell", title, text, true);
    }

    /** Whale walls placed, pulled or hit since the previous check. */
    private void checkWalls(double whale, double range) {
        Map<String, double[][][]> books = new HashMap<>();
        if (perpOn) {
            fetchBook(books, "Binance perp", "https://fapi.binance.com/fapi/v1/depth?symbol=" + sym[0] + "&limit=1000", "binance");
            fetchBook(books, "Bybit perp", "https://api.bybit.com/v5/market/orderbook?category=linear&symbol=" + sym[4] + "&limit=500", "bybit");
            fetchBook(books, "Bitfinex perp", "https://api-pub.bitfinex.com/v2/book/" + sym[6] + "/P1?len=250", "bitfinex");
            fetchBook(books, "OKX perp", "https://www.okx.com/api/v5/market/books?instId=" + sym[3] + "-SWAP&sz=400", "okxswap");
            fetchBook(books, "Hyperliquid perp", "https://api.hyperliquid.xyz/info", "hyper");
        }
        if (spotOn) {
            fetchBook(books, "Binance spot", "https://api.binance.com/api/v3/depth?symbol=" + sym[0] + "&limit=1000", "binance");
            fetchBook(books, "OKX spot", "https://www.okx.com/api/v5/market/books?instId=" + sym[3] + "&sz=400", "okx");
            fetchBook(books, "Kraken", "https://api.kraken.com/0/public/Depth?pair=" + sym[2] + "&count=500", "kraken");
            fetchBook(books, "Bitfinex spot", "https://api-pub.bitfinex.com/v2/book/" + sym[5] + "/P1?len=250", "bitfinex");
            fetchBook(books, "Bybit spot", "https://api.bybit.com/v5/market/orderbook?category=spot&symbol=" + sym[4] + "&limit=200", "bybit");
        }

        Set<String> okVenues = books.keySet();
        Map<String, Double> mids = new HashMap<>();
        List<Wall> current = new ArrayList<>();
        for (Map.Entry<String, double[][][]> e : books.entrySet()) {
            double[][] bids = e.getValue()[0], asks = e.getValue()[1];
            if (bids.length == 0 || asks.length == 0) continue;
            double mid = (bids[0][0] + asks[0][0]) / 2;
            mids.put(e.getKey(), mid);
            for (double[] l : bids) if (l[1] >= whale && l[0] >= mid * (1 - range)) current.add(wall(e.getKey(), "bid", l));
            for (double[] l : asks) if (l[1] >= whale && l[0] <= mid * (1 + range)) current.add(wall(e.getKey(), "ask", l));
        }

        Map<String, Wall> next = new HashMap<>();
        Set<String> matchedPrev = new HashSet<>();
        for (Wall w : current) {
            Wall prev = null;
            String prevKey = null;
            for (Map.Entry<String, Wall> pe : st.walls.entrySet()) {
                Wall p = pe.getValue();
                if (p.venue.equals(w.venue) && p.side.equals(w.side) && Math.abs(p.price - w.price) / w.price <= 0.0005 && !matchedPrev.contains(pe.getKey())) {
                    prev = p;
                    prevKey = pe.getKey();
                    break;
                }
            }
            if (prev != null) {
                matchedPrev.add(prevKey);
                w.seen = prev.seen + 1;
                w.alerted = prev.alerted;
            } else {
                w.seen = 1;
                w.alerted = first; // walls already there when alerts start are not "new"
            }
            if (!w.alerted && w.seen >= 2) {
                w.alerted = true;
                Double mid = mids.get(w.venue);
                double dist = mid == null ? 0 : (w.price - mid) / mid * 100;
                alert(marketOf(w.venue), "wall", String.format(Locale.UK, "🐋 New %s %s %s wall at %s", fmtQty(w.qty), coin, w.side, fmtPrice(w.price)),
                        String.format(Locale.UK, "%s · %+.2f%% from price · %s", w.venue, dist, fmtUsd(w.qty * w.price)), true);
            }
            next.put(w.venue + "|" + w.side + "|" + w.price, w);
        }

        // walls that disappeared
        for (Map.Entry<String, Wall> pe : st.walls.entrySet()) {
            if (matchedPrev.contains(pe.getKey())) continue;
            Wall p = pe.getValue();
            if (!okVenues.contains(p.venue)) { // venue didn't answer: keep it, unless its market was switched off
                if ("spot".equals(marketOf(p.venue)) ? spotOn : perpOn) next.put(pe.getKey(), p);
                continue;
            }
            if (p.seen < 2 || first) continue;
            Double mid = mids.get(p.venue);
            if (mid == null) continue;
            boolean reached = "bid".equals(p.side) ? mid <= p.price * 1.0005 : mid >= p.price * 0.9995;
            if (reached) {
                alert(marketOf(p.venue), "wall", String.format(Locale.UK, "💥 %s %s %s wall at %s was hit", fmtQty(p.qty), coin, p.side, fmtPrice(p.price)),
                        p.venue + " · price reached it and the wall is gone", true);
            } else {
                alert(marketOf(p.venue), "wall", String.format(Locale.UK, "👻 %s %s %s wall at %s pulled", fmtQty(p.qty), coin, p.side, fmtPrice(p.price)),
                        String.format(Locale.UK, "%s · removed before price got there (%+.2f%% away)", p.venue, (p.price - mid) / mid * 100), true);
            }
        }
        st.walls.clear();
        st.walls.putAll(next);
    }

    private static String marketOf(String venue) {
        return venue.contains("perp") ? "perp" : "spot";
    }

    private static Wall wall(String venue, String side, double[] l) {
        Wall w = new Wall();
        w.venue = venue;
        w.side = side;
        w.price = l[0];
        w.qty = l[1];
        return w;
    }

    private void fetchBook(Map<String, double[][][]> out, String venue, String url, String kind) {
        if ("hyper".equals(kind)) {
            // 20 grouped levels per side: [[{px, sz, n}...bids], [...asks]]
            try {
                JSONObject o = new JSONObject(post(url, "{\"type\":\"l2Book\",\"coin\":\"" + sym[7] + "\",\"nSigFigs\":" + sym[8] + "}"));
                JSONArray lv = o.getJSONArray("levels");
                double[][][] side = new double[2][][];
                for (int s = 0; s < 2; s++) {
                    JSONArray a = lv.getJSONArray(s);
                    side[s] = new double[a.length()][2];
                    for (int i = 0; i < a.length(); i++) {
                        JSONObject l = a.getJSONObject(i);
                        side[s][i][0] = Double.parseDouble(l.getString("px"));
                        side[s][i][1] = Double.parseDouble(l.getString("sz"));
                    }
                }
                out.put(venue, side);
            } catch (Exception ignored) {
            }
            return;
        }
        if ("bitfinex".equals(kind)) {
            // rows are [price, orders, amount]; amount > 0 is a bid, < 0 an ask (bids come first, best price first)
            try {
                JSONArray rows = new JSONArray(get(url));
                List<double[]> bids = new ArrayList<>(), asks = new ArrayList<>();
                for (int i = 0; i < rows.length(); i++) {
                    JSONArray r = rows.getJSONArray(i);
                    double price = r.getDouble(0), amt = r.getDouble(2);
                    if (amt > 0) bids.add(new double[]{price, amt});
                    else if (amt < 0) asks.add(new double[]{price, -amt});
                }
                bids.sort((x, y) -> Double.compare(y[0], x[0]));
                asks.sort((x, y) -> Double.compare(x[0], y[0]));
                out.put(venue, new double[][][]{bids.toArray(new double[0][]), asks.toArray(new double[0][])});
            } catch (Exception ignored) {
            }
            return;
        }
        try {
            JSONObject o = new JSONObject(get(url));
            JSONArray b, a;
            switch (kind) {
                case "bybit":
                    b = o.getJSONObject("result").getJSONArray("b");
                    a = o.getJSONObject("result").getJSONArray("a");
                    break;
                case "okx":
                case "okxswap":
                    JSONObject d = o.getJSONArray("data").getJSONObject(0);
                    b = d.getJSONArray("bids");
                    a = d.getJSONArray("asks");
                    break;
                case "kraken":
                    JSONObject r = o.getJSONObject("result");
                    JSONObject pair = r.getJSONObject(r.keys().next());
                    b = pair.getJSONArray("bids");
                    a = pair.getJSONArray("asks");
                    break;
                default:
                    b = o.getJSONArray("bids");
                    a = o.getJSONArray("asks");
            }
            double[][] bl = levels(b), al = levels(a);
            if ("okxswap".equals(kind)) { // contracts -> coins
                double cv = ctVal();
                for (double[] l : bl) l[1] *= cv;
                for (double[] l : al) l[1] *= cv;
            }
            out.put(venue, new double[][][]{bl, al});
        } catch (Exception ignored) {
        }
    }

    private static double[][] levels(JSONArray arr) throws Exception {
        double[][] out = new double[arr.length()][2];
        for (int i = 0; i < arr.length(); i++) {
            JSONArray l = arr.getJSONArray(i);
            out[i][0] = Double.parseDouble(l.getString(0));
            out[i][1] = Double.parseDouble(l.getString(1));
        }
        return out;
    }

    // ------------------------------------------------------------------ notifications

    private void alert(String market, String kind, String title, String text, boolean groupable) {
        title = ("spot".equals(market) ? "SPOT · " : "signal".equals(market) ? "SIGNAL · " : "PERP · ") + title;
        Prefs.addAlert(this, "signal".equals(market) ? "signal" : kind + " " + market, title, text);
        // cap notifications per check; extras are rolled into one summary
        if (groupable && alertsThisCheck >= 4) {
            overflow.add(title);
            return;
        }
        alertsThisCheck++;
        show("spot".equals(market) ? CH_SPOT : "signal".equals(market) ? CH_SIG : CH_PERP, title, text);
    }

    private void show(String channel, String title, String text) {
        Notification.Builder nb = builder(channel)
                .setContentTitle(title)
                .setContentText(text)
                .setStyle(new Notification.BigTextStyle().bigText(text))
                .setAutoCancel(true)
                .setWhen(System.currentTimeMillis())
                .setShowWhen(true);
        if (Build.VERSION.SDK_INT < 26) {
            nb.setPriority(Notification.PRIORITY_HIGH).setDefaults(Notification.DEFAULT_ALL);
        }
        nm.notify(nextAlertId++, nb.build());
        if (nextAlertId > 10_000) nextAlertId = 100;
    }

    private Notification statusNotification(String text) {
        return builder(CH_STATUS)
                .setContentTitle("Whale Book is watching")
                .setContentText(text)
                .setOngoing(true)
                .build();
    }

    private void updateStatus(String text) {
        if (nm != null) nm.notify(STATUS_ID, statusNotification(text));
    }

    private Notification.Builder builder(String channel) {
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, channel)
                : new Notification.Builder(this);
        Intent open = new Intent(this, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return b.setSmallIcon(R.drawable.ic_stat).setContentIntent(pi);
    }

    // ------------------------------------------------------------------ helpers

    private static String post(String u, String body) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
        c.setConnectTimeout(8000);
        c.setReadTimeout(12000);
        c.setRequestMethod("POST");
        c.setDoOutput(true);
        c.setRequestProperty("Content-Type", "application/json");
        c.setRequestProperty("User-Agent", "BTCWhaleBook/1.7");
        try {
            try (java.io.OutputStream os = c.getOutputStream()) { os.write(body.getBytes("UTF-8")); }
            int code = c.getResponseCode();
            if (code != 200) throw new Exception("HTTP " + code);
            try (InputStream in = c.getInputStream()) {
                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                byte[] buf = new byte[16384];
                int n;
                while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
                return bo.toString("UTF-8");
            }
        } finally {
            c.disconnect();
        }
    }

    private static String get(String u) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
        c.setConnectTimeout(8000);
        c.setReadTimeout(12000);
        c.setRequestProperty("User-Agent", "BTCWhaleBook/1.7");
        try {
            int code = c.getResponseCode();
            if (code != 200) throw new Exception("HTTP " + code);
            try (InputStream in = c.getInputStream()) {
                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                byte[] buf = new byte[16384];
                int n;
                while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
                return bo.toString("UTF-8");
            }
        } finally {
            c.disconnect();
        }
    }

    private static String fmtQty(double q) {
        if (q >= 1e6) return String.format(Locale.UK, "%.2fM", q / 1e6);
        return q >= 100 ? String.format(Locale.UK, "%,.0f", q) : String.format(Locale.UK, "%.1f", q);
    }

    private static String fmtPrice(double p) {
        if (p >= 1000) return String.format(Locale.UK, "$%,.0f", p);
        if (p >= 10) return String.format(Locale.UK, "$%,.2f", p);
        return String.format(Locale.UK, "$%.4f", p);
    }

    private static String fmtSigned(double v) {
        return (v >= 0 ? "+" : "−") + fmtQty(Math.abs(v));
    }

    private static String fmtUsd(double v) {
        if (v >= 1e9) return String.format(Locale.UK, "$%.2fB", v / 1e9);
        if (v >= 1e6) return String.format(Locale.UK, "$%.1fM", v / 1e6);
        return String.format(Locale.UK, "$%.0fk", v / 1e3);
    }
}
