package uk.kamil.whalebook;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.PowerManager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * Runs in the background (even with the screen locked) and checks the
 * BTC, ETH and SOL markets the user ticked, on a timer. Sends a notification when:
 *  - a large market order executes (Binance spot/perp, Coinbase)
 *  - buying or selling suddenly speeds up versus the past hour
 *  - a whale wall appears, is pulled, or is hit by price
 */
public class WhaleService extends Service {
    private static final String CH_STATUS = "status";
    private static final String CH_ALERT = "alerts";      // grouped summaries
    private static final String CH_SPOT = "spot_alerts";
    private static final String CH_PERP = "perp_alerts";
    private static final String CH_SIG = "signal_alerts";
    private static final int STATUS_ID = 1;

    private HandlerThread thread;
    private Handler handler;
    private PowerManager.WakeLock wakeLock;
    private NotificationManager nm;
    private int nextAlertId = 100;

    // exchange symbols per coin: Binance, Coinbase, Kraken, OKX, Bybit
    private static final String[] COINS = {"BTC", "ETH", "SOL"};
    private static final Map<String, String[]> SYM = new HashMap<>();
    static {
        SYM.put("BTC", new String[]{"BTCUSDT", "BTC-USD", "XBTUSD", "BTC-USDT", "BTCUSDT"});
        SYM.put("ETH", new String[]{"ETHUSDT", "ETH-USD", "ETHUSD", "ETH-USDT", "ETHUSDT"});
        SYM.put("SOL", new String[]{"SOLUSDT", "SOL-USD", "SOLUSD", "SOL-USDT", "SOLUSDT"});
    }
    // whale wall, big spot order, big perp order, spot 5-min net, perp 5-min net
    private static final Map<String, double[]> DEFAULTS = new HashMap<>();
    static {
        DEFAULTS.put("BTC", new double[]{50, 10, 25, 30, 100});
        DEFAULTS.put("ETH", new double[]{1500, 300, 800, 1000, 3000});
        DEFAULTS.put("SOL", new double[]{40000, 8000, 20000, 25000, 80000});
    }

    /** What the watcher remembers about one coin between checks. */
    private static final class CoinState {
        boolean first = true;
        long lastSpotId = -1, lastPerpId = -1, lastCbId = -1;
        final long[] lastPace = new long[4]; // spot buy, spot sell, perp buy, perp sell
        String pendingSig = null;            // a signal must show on two checks in a row
        final Map<String, Long> lastSig = new HashMap<>();
        final Map<String, Wall> walls = new HashMap<>();
    }
    private final Map<String, CoinState> states = new HashMap<>();

    // the coin being checked right now
    private String coin = "BTC";
    private String[] sym = SYM.get("BTC");
    private CoinState st;
    private boolean first;
    private int alertsThisCheck = 0;
    private boolean spotOn = true, perpOn = true, sigOn = true;
    // last hour of 1-minute data from checkFlow, [0] = spot, [1] = perp
    private final double[][] flowBuy = new double[2][], flowSell = new double[2][], flowClose = new double[2][];
    private final List<String> overflow = new ArrayList<>();

    private static final class Wall {
        String venue, side;
        double price, qty;
        int seen;
        boolean alerted;
    }

    public static void start(Context c) {
        Intent i = new Intent(c, WhaleService.class);
        if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i);
        else c.startService(i);
    }

    private final Runnable loop = new Runnable() {
        @Override
        public void run() {
            int interval = 60;
            try {
                interval = Math.max(20, Prefs.settings(WhaleService.this).optInt("interval", 60));
                check();
            } catch (Throwable t) {
                updateStatus("Connection problem, retrying…");
            }
            if (handler != null) handler.postDelayed(this, interval * 1000L);
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel st = new NotificationChannel(CH_STATUS, "Running status", NotificationManager.IMPORTANCE_LOW);
            st.setShowBadge(false);
            nm.createNotificationChannel(st);
            NotificationChannel al = new NotificationChannel(CH_ALERT, "Grouped whale alerts", NotificationManager.IMPORTANCE_HIGH);
            al.enableVibration(true);
            nm.createNotificationChannel(al);
            NotificationChannel sp = new NotificationChannel(CH_SPOT, "Spot alerts", NotificationManager.IMPORTANCE_HIGH);
            sp.enableVibration(true);
            nm.createNotificationChannel(sp);
            NotificationChannel pp = new NotificationChannel(CH_PERP, "Perp alerts", NotificationManager.IMPORTANCE_HIGH);
            pp.enableVibration(true);
            nm.createNotificationChannel(pp);
            NotificationChannel sg = new NotificationChannel(CH_SIG, "Spot vs perp signals", NotificationManager.IMPORTANCE_HIGH);
            sg.enableVibration(true);
            nm.createNotificationChannel(sg);
        }
        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "whalebook:check");
        wakeLock.setReferenceCounted(false);
        wakeLock.acquire();
        thread = new HandlerThread("whale-check");
        thread.start();
        handler = new Handler(thread.getLooper());
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Notification n = statusNotification("Starting…");
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(STATUS_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
        } else {
            startForeground(STATUS_ID, n);
        }
        if (!Prefs.enabled(this)) {
            stopSelf();
            return START_NOT_STICKY;
        }
        handler.removeCallbacks(loop);
        handler.post(loop);
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        if (handler != null) handler.removeCallbacksAndMessages(null);
        if (thread != null) thread.quitSafely();
        handler = null;
        if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    // ------------------------------------------------------------------ checks

    private void check() throws Exception {
        JSONObject s = Prefs.settings(this);
        double accel = s.optDouble("accel", 3);
        double range = s.optDouble("range", 2) / 100.0;
        spotOn = s.optBoolean("spotOn", true);
        perpOn = s.optBoolean("perpOn", true);
        sigOn = s.optBoolean("sigOn", true);
        JSONObject coins = s.optJSONObject("coins");
        alertsThisCheck = 0;
        overflow.clear();

        List<String> status = new ArrayList<>();
        for (String c : COINS) {
            double[] d = DEFAULTS.get(c);
            boolean on;
            JSONObject o;
            if (coins != null) {
                o = coins.optJSONObject(c);
                on = o != null && o.optBoolean("on", false);
            } else { // settings saved by version 1.1 (BTC only)
                o = s;
                on = "BTC".equals(c);
            }
            if (o == null) o = new JSONObject();
            double whale = o.optDouble("whale", d[0]);
            double execSpot = o.optDouble("execSpot", d[1]);
            double execPerp = o.optDouble("execPerp", o.optDouble("exec", d[2]));   // "exec" = older versions
            double netSpot = o.optDouble("netSpot", d[3]);
            double netPerp = o.optDouble("netPerp", o.optDouble("minNet", d[4]));
            if (!on) {
                states.remove(c); // start fresh if it is switched back on later
                continue;
            }
            coin = c;
            sym = SYM.get(c);
            st = states.get(c);
            if (st == null) { st = new CoinState(); states.put(c, st); }
            first = st.first;

            String line = "";
            try {
                line = checkFlow(accel, netSpot, netPerp);
            } catch (Exception ignored) {
            }
            try {
                if (sigOn) checkSignal();
            } catch (Exception ignored) {
            }
            try {
                checkExecutions(execSpot, execPerp);
            } catch (Exception ignored) {
            }
            try {
                checkWalls(whale, range);
            } catch (Exception ignored) {
            }
            st.first = false;
            status.add(line.isEmpty() ? c : line);
        }
        if (!overflow.isEmpty()) {
            show(CH_ALERT, "🐋 " + overflow.size() + " more whale events", String.join(" · ", overflow));
        }
        String time = String.format(Locale.UK, "%tR", Calendar.getInstance());
        String none = status.isEmpty() ? "No coins ticked" : (!spotOn && !perpOn && !sigOn ? "Nothing ticked under Markets" : null);
        updateStatus((none != null ? none : String.join(" · ", status)) + " · " + time);
    }

    /**
     * Pace alerts and today's totals, kept separate for Binance spot and Binance perps.
     * Spot = coins actually bought or sold; perps = leveraged positions.
     */
    private String checkFlow(double accel, double netSpot, double netPerp) {
        String[] label = {"SPOT", "PERP"};
        String[] base = {"https://api.binance.com/api/v3/klines?symbol=", "https://fapi.binance.com/fapi/v1/klines?symbol="};
        double[] thr = {netSpot, netPerp};
        boolean[] on = {spotOn, perpOn};
        double price = 0;
        long now = System.currentTimeMillis();
        flowBuy[0] = flowBuy[1] = flowSell[0] = flowSell[1] = flowClose[0] = flowClose[1] = null;
        for (int m = 0; m < 2; m++) {
            if (!on[m] && !sigOn) continue;
            double[] buy = new double[60], sell = new double[60], close = new double[60];
            try {
                JSONArray k = new JSONArray(get(base[m] + sym[0] + "&interval=1m&limit=60"));
                int off = 60 - k.length();
                for (int i = 0; i < k.length(); i++) {
                    JSONArray c = k.getJSONArray(i);
                    double vol = Double.parseDouble(c.getString(5));
                    double b = Double.parseDouble(c.getString(9));
                    buy[off + i] = b;
                    sell[off + i] = vol - b;
                    close[off + i] = Double.parseDouble(c.getString(4));
                    if (m == 0 || price == 0) price = Double.parseDouble(c.getString(4));
                }
            } catch (Exception e) {
                continue;
            }
            flowBuy[m] = buy;
            flowSell[m] = sell;
            flowClose[m] = close;
            if (!on[m]) continue; // fetched only for the spot-vs-perp signal
            double b5 = 0, s5 = 0, bBase = 0, sBase = 0;
            for (int i = 55; i < 60; i++) { b5 += buy[i]; s5 += sell[i]; }
            for (int i = 0; i < 55; i++) { bBase += buy[i]; sBase += sell[i]; }
            double avgB = bBase / 11.0, avgS = sBase / 11.0; // average per 5 minutes
            double net = b5 - s5;
            String market = m == 0 ? "spot" : "perp";
            if (!first && avgS > 0 && s5 / avgS >= accel && -net >= thr[m] && now - st.lastPace[m * 2 + 1] > 10 * 60_000) {
                st.lastPace[m * 2 + 1] = now;
                alert(market, "sell", String.format(Locale.UK, "⚠ %s %s selling accelerating: %.1f× normal", coin, label[m].toLowerCase(Locale.UK), s5 / avgS),
                        String.format(Locale.UK, "Binance %s · net %s %s in the last 5 min · price %s", market, fmtSigned(net), coin, fmtPrice(price)), false);
            }
            if (!first && avgB > 0 && b5 / avgB >= accel && net >= thr[m] && now - st.lastPace[m * 2] > 10 * 60_000) {
                st.lastPace[m * 2] = now;
                alert(market, "buy", String.format(Locale.UK, "⚠ %s %s buying accelerating: %.1f× normal", coin, label[m].toLowerCase(Locale.UK), b5 / avgB),
                        String.format(Locale.UK, "Binance %s · net %s %s in the last 5 min · price %s", market, fmtSigned(net), coin, fmtPrice(price)), false);
            }
        }

        // today's net since local midnight, per market (5-minute candles)
        Calendar mid = Calendar.getInstance();
        mid.set(Calendar.HOUR_OF_DAY, 0);
        mid.set(Calendar.MINUTE, 0);
        mid.set(Calendar.SECOND, 0);
        mid.set(Calendar.MILLISECOND, 0);
        long start = mid.getTimeInMillis();
        StringBuilder out = new StringBuilder(coin);
        if (price > 0) out.append(" ").append(fmtPrice(price));
        for (int m = 0; m < 2; m++) {
            if (!on[m]) continue;
            try {
                JSONArray k = new JSONArray(get(base[m] + sym[0] + "&interval=5m&limit=288&startTime=" + start));
                double net = 0;
                for (int i = 0; i < k.length(); i++) {
                    JSONArray c = k.getJSONArray(i);
                    double vol = Double.parseDouble(c.getString(5));
                    double b = Double.parseDouble(c.getString(9));
                    net += b - (vol - b);
                }
                out.append(m == 0 ? " spot " : " perp ").append(fmtSigned(net));
            } catch (Exception ignored) {
            }
        }
        return out.toString();
    }

    /**
     * Spot vs perps over the last hour. Same rules as the dashboard's "who is driving?" panel.
     * Alerts only on the readings worth acting on, after two checks in a row, at most once an hour each.
     */
    private void checkSignal() {
        if (flowBuy[0] == null || flowBuy[1] == null) return;
        double sB = 0, sS = 0, pB = 0, pS = 0;
        for (int i = 0; i < 60; i++) { sB += flowBuy[0][i]; sS += flowSell[0][i]; pB += flowBuy[1][i]; pS += flowSell[1][i]; }
        if (sB + sS <= 0 || pB + pS <= 0) return;
        double sImb = (sB - sS) / (sB + sS), pImb = (pB - pS) / (pB + pS);
        double[] cl = flowClose[0];
        double p0 = 0, p1 = cl[59];
        for (double v : cl) if (v > 0) { p0 = v; break; }
        if (p0 <= 0 || p1 <= 0) return;
        double dP = (p1 - p0) / p0 * 100;
        Double dOI = null;
        try {
            JSONArray oi = new JSONArray(get("https://fapi.binance.com/futures/data/openInterestHist?symbol=" + sym[0] + "&period=5m&limit=13"));
            if (oi.length() >= 2) {
                double o0 = Double.parseDouble(oi.getJSONObject(0).getString("sumOpenInterest"));
                double o1 = Double.parseDouble(oi.getJSONObject(oi.length() - 1).getString("sumOpenInterest"));
                if (o0 > 0) dOI = (o1 - o0) / o0 * 100;
            }
        } catch (Exception ignored) {
        }
        Double funding = null;
        try {
            funding = Double.parseDouble(new JSONObject(get("https://fapi.binance.com/fapi/v1/premiumIndex?symbol=" + sym[0])).getString("lastFundingRate"));
        } catch (Exception ignored) {
        }
        String[] r = classify(sImb, pImb, dP, dOI);
        String code = r[0];
        boolean alertable = code.equals("distribution") || code.equals("absorption") || code.equals("short_squeeze")
                || code.equals("leverage_long") || code.equals("long_flush") || code.equals("shorts_piling");
        if (!alertable) { st.pendingSig = null; return; }
        boolean confirmed = code.equals(st.pendingSig);
        st.pendingSig = code;
        if (!confirmed || first) return;
        long now = System.currentTimeMillis();
        Long last = st.lastSig.get(code);
        if (last != null && now - last < 60 * 60_000) return;
        st.lastSig.put(code, now);
        StringBuilder text = new StringBuilder(r[2]);
        text.append(String.format(Locale.UK, " Last hour: spot %+.1f%%, perps %+.1f%% net, price %+.2f%%", sImb * 100, pImb * 100, dP));
        if (dOI != null) text.append(String.format(Locale.UK, ", open interest %+.2f%%", dOI));
        text.append(".");
        if (funding != null && funding >= 0.0003) text.append(" Funding is high: longs crowded.");
        if (funding != null && funding <= -0.0001) text.append(" Funding is negative: shorts crowded.");
        alert("signal", "signal", r[1] + " · " + coin, text.toString(), false);
    }

    /** Returns {code, title, one-line meaning}. Mirrors classify() in the dashboard. */
    private static String[] classify(double sImb, double pImb, double dP, Double dOI) {
        final double I = 0.03, P = 0.3, O = 0.5;
        boolean sBuy = sImb >= I, sSell = sImb <= -I, pBuy = pImb >= I, pSell = pImb <= -I;
        boolean up = dP >= P, dn = dP <= -P;
        boolean oiUp = dOI != null && dOI >= O, oiDn = dOI != null && dOI <= -O;
        if (pBuy && sSell) return new String[]{"distribution", "⚠ Spot selling into perp buying",
                oiUp ? "Spot holders are selling to new leveraged longs: possible exit liquidity. If price stalls, longs can be flushed."
                     : "Spot holders are selling while perp traders buy. If price stalls, those longs are exposed."};
        if (sBuy && pSell) return new String[]{"absorption", "🧲 Spot buying while perps sell",
                oiUp ? "Real buyers are absorbing new leveraged shorts. Squeeze risk upward if price holds."
                     : "Real buyers are absorbing perp selling. Usually supportive for price."};
        if (sBuy && pBuy) return new String[]{"broad_buy", "✅ Spot and perps both buying", "Buyers agree across both markets."};
        if (sSell && pSell) return new String[]{"broad_sell", "🔻 Spot and perps both selling", "Sellers agree across both markets."};
        if (pBuy && up) {
            if (oiDn) return new String[]{"short_squeeze", "🩳 Short squeeze", "Price rising while open interest falls: shorts closing, not new demand. Often runs out once shorts are done."};
            return new String[]{"leverage_long", "🎢 Perp-led rise", "Price rising on perp buying with little spot support. Leverage-led moves fade more often."};
        }
        if (sBuy && up) return new String[]{"spot_rally", "🟢 Spot-led rise", "Real coins are being bought."};
        if (pSell && dn) {
            if (oiDn) return new String[]{"long_flush", "🌊 Long flush", "Price falling while open interest drops: longs closing or being liquidated. Flushes often end sharply."};
            if (oiUp) return new String[]{"shorts_piling", "🐻 Shorts piling in", "Price falling while open interest rises: new shorts opening. Squeeze risk if spot holds firm."};
            return new String[]{"perp_drop", "🔻 Perp-led drop", "Price falling on perp selling."};
        }
        if (sSell && dn) return new String[]{"spot_drop", "🔴 Spot-led drop", "Real coins are being sold."};
        return new String[]{"mixed", "No clear signal", ""};
    }

    /** Large market orders since the previous check. */
    private void checkExecutions(double execSpot, double execPerp) throws Exception {
        if (perpOn) st.lastPerpId = binanceTrades("https://fapi.binance.com/fapi/v1/aggTrades?symbol=" + sym[0], st.lastPerpId, execPerp, "Binance perp", "perp");
        else st.lastPerpId = -1;
        if (!spotOn) { st.lastSpotId = -1; st.lastCbId = -1; return; }
        st.lastSpotId = binanceTrades("https://api.binance.com/api/v3/aggTrades?symbol=" + sym[0], st.lastSpotId, execSpot, "Binance spot", "spot");
        double exec = execSpot;
        try {
            JSONArray t = new JSONArray(get("https://api.exchange.coinbase.com/products/" + sym[1] + "/trades?limit=1000"));
            long maxId = st.lastCbId;
            for (int i = 0; i < t.length(); i++) {
                JSONObject o = t.getJSONObject(i);
                long id = o.getLong("trade_id");
                if (id > maxId) maxId = id;
                if (st.lastCbId < 0 || id <= st.lastCbId) continue;
                double q = Double.parseDouble(o.getString("size"));
                if (q < exec) continue;
                double p = Double.parseDouble(o.getString("price"));
                // Coinbase reports the maker side; the market order is the opposite
                boolean buy = "sell".equals(o.getString("side"));
                executionAlert(buy, q, p, "Coinbase", "spot");
            }
            st.lastCbId = maxId;
        } catch (Exception ignored) {
        }
    }

    private long binanceTrades(String base, long lastId, double exec, String venue, String market) {
        try {
            if (lastId < 0) {
                JSONArray t = new JSONArray(get(base + "&limit=1"));
                return t.length() > 0 ? t.getJSONObject(0).getLong("a") : -1;
            }
            long id = lastId;
            for (int page = 0; page < 4; page++) {
                JSONArray t = new JSONArray(get(base + "&limit=1000&fromId=" + (id + 1)));
                for (int i = 0; i < t.length(); i++) {
                    JSONObject o = t.getJSONObject(i);
                    id = Math.max(id, o.getLong("a"));
                    double q = Double.parseDouble(o.getString("q"));
                    if (q < exec) continue;
                    double p = Double.parseDouble(o.getString("p"));
                    boolean buy = !o.getBoolean("m"); // m = buyer was maker → a market sell
                    executionAlert(buy, q, p, venue, market);
                }
                if (t.length() < 1000) break;
            }
            return id;
        } catch (Exception e) {
            return lastId;
        }
    }

    private void executionAlert(boolean buy, double q, double p, String venue, String market) {
        String title = String.format(Locale.UK, "🐋 %s %s market %s", fmtQty(q), coin, buy ? "BUY" : "SELL");
        String text = String.format(Locale.UK, "%s at %s (%s)", venue, fmtPrice(p), fmtUsd(q * p));
        alert(market, buy ? "buy" : "sell", title, text, true);
    }

    /** Whale walls placed, pulled or hit since the previous check. */
    private void checkWalls(double whale, double range) {
        Map<String, double[][][]> books = new HashMap<>();
        if (perpOn) {
            fetchBook(books, "Binance perp", "https://fapi.binance.com/fapi/v1/depth?symbol=" + sym[0] + "&limit=1000", "binance");
            fetchBook(books, "Bybit perp", "https://api.bybit.com/v5/market/orderbook?category=linear&symbol=" + sym[4] + "&limit=500", "bybit");
        }
        if (spotOn) {
            fetchBook(books, "Binance spot", "https://api.binance.com/api/v3/depth?symbol=" + sym[0] + "&limit=1000", "binance");
            fetchBook(books, "OKX spot", "https://www.okx.com/api/v5/market/books?instId=" + sym[3] + "&sz=400", "okx");
            fetchBook(books, "Kraken", "https://api.kraken.com/0/public/Depth?pair=" + sym[2] + "&count=500", "kraken");
        }

        Set<String> okVenues = books.keySet();
        Map<String, Double> mids = new HashMap<>();
        List<Wall> current = new ArrayList<>();
        for (Map.Entry<String, double[][][]> e : books.entrySet()) {
            double[][] bids = e.getValue()[0], asks = e.getValue()[1];
            if (bids.length == 0 || asks.length == 0) continue;
            double mid = (bids[0][0] + asks[0][0]) / 2;
            mids.put(e.getKey(), mid);
            for (double[] l : bids) if (l[1] >= whale && l[0] >= mid * (1 - range)) current.add(wall(e.getKey(), "bid", l));
            for (double[] l : asks) if (l[1] >= whale && l[0] <= mid * (1 + range)) current.add(wall(e.getKey(), "ask", l));
        }

        Map<String, Wall> next = new HashMap<>();
        Set<String> matchedPrev = new HashSet<>();
        for (Wall w : current) {
            Wall prev = null;
            String prevKey = null;
            for (Map.Entry<String, Wall> pe : st.walls.entrySet()) {
                Wall p = pe.getValue();
                if (p.venue.equals(w.venue) && p.side.equals(w.side) && Math.abs(p.price - w.price) / w.price <= 0.0005 && !matchedPrev.contains(pe.getKey())) {
                    prev = p;
                    prevKey = pe.getKey();
                    break;
                }
            }
            if (prev != null) {
                matchedPrev.add(prevKey);
                w.seen = prev.seen + 1;
                w.alerted = prev.alerted;
            } else {
                w.seen = 1;
                w.alerted = first; // walls already there when alerts start are not "new"
            }
            if (!w.alerted && w.seen >= 2) {
                w.alerted = true;
                Double mid = mids.get(w.venue);
                double dist = mid == null ? 0 : (w.price - mid) / mid * 100;
                alert(marketOf(w.venue), "wall", String.format(Locale.UK, "🐋 New %s %s %s wall at %s", fmtQty(w.qty), coin, w.side, fmtPrice(w.price)),
                        String.format(Locale.UK, "%s · %+.2f%% from price · %s", w.venue, dist, fmtUsd(w.qty * w.price)), true);
            }
            next.put(w.venue + "|" + w.side + "|" + w.price, w);
        }

        // walls that disappeared
        for (Map.Entry<String, Wall> pe : st.walls.entrySet()) {
            if (matchedPrev.contains(pe.getKey())) continue;
            Wall p = pe.getValue();
            if (!okVenues.contains(p.venue)) { // venue didn't answer: keep it, unless its market was switched off
                if ("spot".equals(marketOf(p.venue)) ? spotOn : perpOn) next.put(pe.getKey(), p);
                continue;
            }
            if (p.seen < 2 || first) continue;
            Double mid = mids.get(p.venue);
            if (mid == null) continue;
            boolean reached = "bid".equals(p.side) ? mid <= p.price * 1.0005 : mid >= p.price * 0.9995;
            if (reached) {
                alert(marketOf(p.venue), "wall", String.format(Locale.UK, "💥 %s %s %s wall at %s was hit", fmtQty(p.qty), coin, p.side, fmtPrice(p.price)),
                        p.venue + " · price reached it and the wall is gone", true);
            } else {
                alert(marketOf(p.venue), "wall", String.format(Locale.UK, "👻 %s %s %s wall at %s pulled", fmtQty(p.qty), coin, p.side, fmtPrice(p.price)),
                        String.format(Locale.UK, "%s · removed before price got there (%+.2f%% away)", p.venue, (p.price - mid) / mid * 100), true);
            }
        }
        st.walls.clear();
        st.walls.putAll(next);
    }

    private static String marketOf(String venue) {
        return venue.contains("perp") ? "perp" : "spot";
    }

    private static Wall wall(String venue, String side, double[] l) {
        Wall w = new Wall();
        w.venue = venue;
        w.side = side;
        w.price = l[0];
        w.qty = l[1];
        return w;
    }

    private void fetchBook(Map<String, double[][][]> out, String venue, String url, String kind) {
        try {
            JSONObject o = new JSONObject(get(url));
            JSONArray b, a;
            switch (kind) {
                case "bybit":
                    b = o.getJSONObject("result").getJSONArray("b");
                    a = o.getJSONObject("result").getJSONArray("a");
                    break;
                case "okx":
                    JSONObject d = o.getJSONArray("data").getJSONObject(0);
                    b = d.getJSONArray("bids");
                    a = d.getJSONArray("asks");
                    break;
                case "kraken":
                    JSONObject r = o.getJSONObject("result");
                    JSONObject pair = r.getJSONObject(r.keys().next());
                    b = pair.getJSONArray("bids");
                    a = pair.getJSONArray("asks");
                    break;
                default:
                    b = o.getJSONArray("bids");
                    a = o.getJSONArray("asks");
            }
            out.put(venue, new double[][][]{levels(b), levels(a)});
        } catch (Exception ignored) {
        }
    }

    private static double[][] levels(JSONArray arr) throws Exception {
        double[][] out = new double[arr.length()][2];
        for (int i = 0; i < arr.length(); i++) {
            JSONArray l = arr.getJSONArray(i);
            out[i][0] = Double.parseDouble(l.getString(0));
            out[i][1] = Double.parseDouble(l.getString(1));
        }
        return out;
    }

    // ------------------------------------------------------------------ notifications

    private void alert(String market, String kind, String title, String text, boolean groupable) {
        title = ("spot".equals(market) ? "SPOT · " : "signal".equals(market) ? "SIGNAL · " : "PERP · ") + title;
        Prefs.addAlert(this, "signal".equals(market) ? "signal" : kind + " " + market, title, text);
        // cap notifications per check; extras are rolled into one summary
        if (groupable && alertsThisCheck >= 4) {
            overflow.add(title);
            return;
        }
        alertsThisCheck++;
        show("spot".equals(market) ? CH_SPOT : "signal".equals(market) ? CH_SIG : CH_PERP, title, text);
    }

    private void show(String channel, String title, String text) {
        Notification.Builder nb = builder(channel)
                .setContentTitle(title)
                .setContentText(text)
                .setStyle(new Notification.BigTextStyle().bigText(text))
                .setAutoCancel(true)
                .setWhen(System.currentTimeMillis())
                .setShowWhen(true);
        if (Build.VERSION.SDK_INT < 26) {
            nb.setPriority(Notification.PRIORITY_HIGH).setDefaults(Notification.DEFAULT_ALL);
        }
        nm.notify(nextAlertId++, nb.build());
        if (nextAlertId > 10_000) nextAlertId = 100;
    }

    private Notification statusNotification(String text) {
        return builder(CH_STATUS)
                .setContentTitle("Whale Book is watching")
                .setContentText(text)
                .setOngoing(true)
                .build();
    }

    private void updateStatus(String text) {
        if (nm != null) nm.notify(STATUS_ID, statusNotification(text));
    }

    private Notification.Builder builder(String channel) {
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, channel)
                : new Notification.Builder(this);
        Intent open = new Intent(this, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return b.setSmallIcon(R.drawable.ic_stat).setContentIntent(pi);
    }

    // ------------------------------------------------------------------ helpers

    private static String get(String u) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
        c.setConnectTimeout(8000);
        c.setReadTimeout(12000);
        c.setRequestProperty("User-Agent", "BTCWhaleBook/1.5");
        try {
            int code = c.getResponseCode();
            if (code != 200) throw new Exception("HTTP " + code);
            try (InputStream in = c.getInputStream()) {
                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                byte[] buf = new byte[16384];
                int n;
                while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
                return bo.toString("UTF-8");
            }
        } finally {
            c.disconnect();
        }
    }

    private static String fmtQty(double q) {
        if (q >= 1e6) return String.format(Locale.UK, "%.2fM", q / 1e6);
        return q >= 100 ? String.format(Locale.UK, "%,.0f", q) : String.format(Locale.UK, "%.1f", q);
    }

    private static String fmtPrice(double p) {
        if (p >= 1000) return String.format(Locale.UK, "$%,.0f", p);
        if (p >= 10) return String.format(Locale.UK, "$%,.2f", p);
        return String.format(Locale.UK, "$%.4f", p);
    }

    private static String fmtSigned(double v) {
        return (v >= 0 ? "+" : "−") + fmtQty(Math.abs(v));
    }

    private static String fmtUsd(double v) {
        if (v >= 1e9) return String.format(Locale.UK, "$%.2fB", v / 1e9);
        if (v >= 1e6) return String.format(Locale.UK, "$%.1fM", v / 1e6);
        return String.format(Locale.UK, "$%.0fk", v / 1e3);
    }
}
