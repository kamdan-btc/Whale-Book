package uk.kamil.whalebook;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.PowerManager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * Runs in the background (even with the screen locked) and checks the
 * BTC, ETH and SOL markets the user ticked, on a timer. Sends a notification when:
 *  - a large market order executes (Binance spot/perp, Coinbase)
 *  - buying or selling suddenly speeds up versus the past hour
 *  - a whale wall appears, is pulled, or is hit by price
 */
public class WhaleService extends Service {
    private static final String CH_STATUS = "status";
    private static final String CH_ALERT = "alerts";
    private static final int STATUS_ID = 1;

    private HandlerThread thread;
    private Handler handler;
    private PowerManager.WakeLock wakeLock;
    private NotificationManager nm;
    private int nextAlertId = 100;

    // exchange symbols per coin: Binance, Coinbase, Kraken, OKX, Bybit
    private static final String[] COINS = {"BTC", "ETH", "SOL"};
    private static final Map<String, String[]> SYM = new HashMap<>();
    static {
        SYM.put("BTC", new String[]{"BTCUSDT", "BTC-USD", "XBTUSD", "BTC-USDT", "BTCUSDT"});
        SYM.put("ETH", new String[]{"ETHUSDT", "ETH-USD", "ETHUSD", "ETH-USDT", "ETHUSDT"});
        SYM.put("SOL", new String[]{"SOLUSDT", "SOL-USD", "SOLUSD", "SOL-USDT", "SOLUSDT"});
    }
    private static final Map<String, double[]> DEFAULTS = new HashMap<>(); // whale, exec, minNet
    static {
        DEFAULTS.put("BTC", new double[]{50, 25, 100});
        DEFAULTS.put("ETH", new double[]{1500, 800, 3000});
        DEFAULTS.put("SOL", new double[]{40000, 20000, 80000});
    }

    /** What the watcher remembers about one coin between checks. */
    private static final class CoinState {
        boolean first = true;
        long lastSpotId = -1, lastPerpId = -1, lastCbId = -1;
        long lastBuyAlert = 0, lastSellAlert = 0;
        final Map<String, Wall> walls = new HashMap<>();
    }
    private final Map<String, CoinState> states = new HashMap<>();

    // the coin being checked right now
    private String coin = "BTC";
    private String[] sym = SYM.get("BTC");
    private CoinState st;
    private boolean first;
    private int alertsThisCheck = 0;
    private final List<String> overflow = new ArrayList<>();

    private static final class Wall {
        String venue, side;
        double price, qty;
        int seen;
        boolean alerted;
    }

    public static void start(Context c) {
        Intent i = new Intent(c, WhaleService.class);
        if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i);
        else c.startService(i);
    }

    private final Runnable loop = new Runnable() {
        @Override
        public void run() {
            int interval = 60;
            try {
                interval = Math.max(20, Prefs.settings(WhaleService.this).optInt("interval", 60));
                check();
            } catch (Throwable t) {
                updateStatus("Connection problem, retrying…");
            }
            if (handler != null) handler.postDelayed(this, interval * 1000L);
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel st = new NotificationChannel(CH_STATUS, "Running status", NotificationManager.IMPORTANCE_LOW);
            st.setShowBadge(false);
            nm.createNotificationChannel(st);
            NotificationChannel al = new NotificationChannel(CH_ALERT, "Whale alerts", NotificationManager.IMPORTANCE_HIGH);
            al.enableVibration(true);
            nm.createNotificationChannel(al);
        }
        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "whalebook:check");
        wakeLock.setReferenceCounted(false);
        wakeLock.acquire();
        thread = new HandlerThread("whale-check");
        thread.start();
        handler = new Handler(thread.getLooper());
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Notification n = statusNotification("Starting…");
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(STATUS_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
        } else {
            startForeground(STATUS_ID, n);
        }
        if (!Prefs.enabled(this)) {
            stopSelf();
            return START_NOT_STICKY;
        }
        handler.removeCallbacks(loop);
        handler.post(loop);
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        if (handler != null) handler.removeCallbacksAndMessages(null);
        if (thread != null) thread.quitSafely();
        handler = null;
        if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    // ------------------------------------------------------------------ checks

    private void check() throws Exception {
        JSONObject s = Prefs.settings(this);
        double accel = s.optDouble("accel", 3);
        double range = s.optDouble("range", 2) / 100.0;
        JSONObject coins = s.optJSONObject("coins");
        alertsThisCheck = 0;
        overflow.clear();

        List<String> status = new ArrayList<>();
        for (String c : COINS) {
            double[] d = DEFAULTS.get(c);
            double whale, exec, minNet;
            boolean on;
            if (coins != null) {
                JSONObject o = coins.optJSONObject(c);
                on = o != null && o.optBoolean("on", false);
                whale = o == null ? d[0] : o.optDouble("whale", d[0]);
                exec = o == null ? d[1] : o.optDouble("exec", d[1]);
                minNet = o == null ? d[2] : o.optDouble("minNet", d[2]);
            } else { // settings saved by version 1.1 (BTC only)
                on = "BTC".equals(c);
                whale = s.optDouble("whale", d[0]);
                exec = s.optDouble("exec", d[1]);
                minNet = s.optDouble("minNet", d[2]);
            }
            if (!on) {
                states.remove(c); // start fresh if it is switched back on later
                continue;
            }
            coin = c;
            sym = SYM.get(c);
            st = states.get(c);
            if (st == null) { st = new CoinState(); states.put(c, st); }
            first = st.first;

            String line = "";
            try {
                line = checkFlow(accel, minNet);
            } catch (Exception ignored) {
            }
            try {
                checkExecutions(exec);
            } catch (Exception ignored) {
            }
            try {
                checkWalls(whale, range);
            } catch (Exception ignored) {
            }
            st.first = false;
            status.add(line.isEmpty() ? c : line);
        }
        if (!overflow.isEmpty()) {
            show("🐋 " + overflow.size() + " more whale events", String.join(" · ", overflow));
        }
        String time = String.format(Locale.UK, "%tR", Calendar.getInstance());
        updateStatus((status.isEmpty() ? "No coins ticked" : String.join(" · ", status)) + " · " + time);
    }

    /** Daily totals and acceleration from Binance spot + perp 1-minute and 5-minute candles. */
    private String checkFlow(double accel, double minNet) throws Exception {
        // last 60 one-minute candles, spot + perp combined
        double[] buy = new double[60], sell = new double[60];
        double price = 0;
        String[] urls = {
                "https://api.binance.com/api/v3/klines?symbol=" + sym[0] + "&interval=1m&limit=60",
                "https://fapi.binance.com/fapi/v1/klines?symbol=" + sym[0] + "&interval=1m&limit=60"
        };
        int ok = 0;
        for (String u : urls) {
            try {
                JSONArray k = new JSONArray(get(u));
                int off = 60 - k.length();
                for (int i = 0; i < k.length(); i++) {
                    JSONArray c = k.getJSONArray(i);
                    double vol = Double.parseDouble(c.getString(5));
                    double b = Double.parseDouble(c.getString(9));
                    buy[off + i] += b;
                    sell[off + i] += vol - b;
                    price = Double.parseDouble(c.getString(4));
                }
                ok++;
            } catch (Exception ignored) {
            }
        }
        if (ok > 0) {
            double b5 = 0, s5 = 0, bBase = 0, sBase = 0;
            for (int i = 55; i < 60; i++) { b5 += buy[i]; s5 += sell[i]; }
            for (int i = 0; i < 55; i++) { bBase += buy[i]; sBase += sell[i]; }
            double avgB = bBase / 11.0, avgS = sBase / 11.0; // average per 5 minutes
            double net = b5 - s5;
            long now = System.currentTimeMillis();
            if (!first && avgS > 0 && s5 / avgS >= accel && -net >= minNet && now - st.lastSellAlert > 10 * 60_000) {
                st.lastSellAlert = now;
                alert("sell", String.format(Locale.UK, "⚠ %s selling accelerating: %.1f× normal", coin, s5 / avgS),
                        String.format(Locale.UK, "Net %s %s in the last 5 min · price %s", fmtSigned(net), coin, fmtPrice(price)), false);
            }
            if (!first && avgB > 0 && b5 / avgB >= accel && net >= minNet && now - st.lastBuyAlert > 10 * 60_000) {
                st.lastBuyAlert = now;
                alert("buy", String.format(Locale.UK, "⚠ %s buying accelerating: %.1f× normal", coin, b5 / avgB),
                        String.format(Locale.UK, "Net %s %s in the last 5 min · price %s", fmtSigned(net), coin, fmtPrice(price)), false);
            }
        }

        // today's totals since local midnight (5-minute candles)
        Calendar mid = Calendar.getInstance();
        mid.set(Calendar.HOUR_OF_DAY, 0);
        mid.set(Calendar.MINUTE, 0);
        mid.set(Calendar.SECOND, 0);
        mid.set(Calendar.MILLISECOND, 0);
        long start = mid.getTimeInMillis();
        double dBuy = 0, dSell = 0;
        String[] dayUrls = {
                "https://api.binance.com/api/v3/klines?symbol=" + sym[0] + "&interval=5m&limit=288&startTime=" + start,
                "https://fapi.binance.com/fapi/v1/klines?symbol=" + sym[0] + "&interval=5m&limit=288&startTime=" + start
        };
        int dOk = 0;
        for (String u : dayUrls) {
            try {
                JSONArray k = new JSONArray(get(u));
                for (int i = 0; i < k.length(); i++) {
                    JSONArray c = k.getJSONArray(i);
                    double vol = Double.parseDouble(c.getString(5));
                    double b = Double.parseDouble(c.getString(9));
                    dBuy += b;
                    dSell += vol - b;
                }
                dOk++;
            } catch (Exception ignored) {
            }
        }
        if (dOk == 0) return price > 0 ? coin + " " + fmtPrice(price) : "";
        return coin + " " + fmtPrice(price) + " (" + fmtSigned(dBuy - dSell) + ")";
    }

    /** Large market orders since the previous check. */
    private void checkExecutions(double exec) throws Exception {
        st.lastSpotId = binanceTrades("https://api.binance.com/api/v3/aggTrades?symbol=" + sym[0], st.lastSpotId, exec, "Binance spot");
        st.lastPerpId = binanceTrades("https://fapi.binance.com/fapi/v1/aggTrades?symbol=" + sym[0], st.lastPerpId, exec, "Binance perp");
        try {
            JSONArray t = new JSONArray(get("https://api.exchange.coinbase.com/products/" + sym[1] + "/trades?limit=1000"));
            long maxId = st.lastCbId;
            for (int i = 0; i < t.length(); i++) {
                JSONObject o = t.getJSONObject(i);
                long id = o.getLong("trade_id");
                if (id > maxId) maxId = id;
                if (st.lastCbId < 0 || id <= st.lastCbId) continue;
                double q = Double.parseDouble(o.getString("size"));
                if (q < exec) continue;
                double p = Double.parseDouble(o.getString("price"));
                // Coinbase reports the maker side; the market order is the opposite
                boolean buy = "sell".equals(o.getString("side"));
                executionAlert(buy, q, p, "Coinbase");
            }
            st.lastCbId = maxId;
        } catch (Exception ignored) {
        }
    }

    private long binanceTrades(String base, long lastId, double exec, String venue) {
        try {
            if (lastId < 0) {
                JSONArray t = new JSONArray(get(base + "&limit=1"));
                return t.length() > 0 ? t.getJSONObject(0).getLong("a") : -1;
            }
            long id = lastId;
            for (int page = 0; page < 4; page++) {
                JSONArray t = new JSONArray(get(base + "&limit=1000&fromId=" + (id + 1)));
                for (int i = 0; i < t.length(); i++) {
                    JSONObject o = t.getJSONObject(i);
                    id = Math.max(id, o.getLong("a"));
                    double q = Double.parseDouble(o.getString("q"));
                    if (q < exec) continue;
                    double p = Double.parseDouble(o.getString("p"));
                    boolean buy = !o.getBoolean("m"); // m = buyer was maker → a market sell
                    executionAlert(buy, q, p, venue);
                }
                if (t.length() < 1000) break;
            }
            return id;
        } catch (Exception e) {
            return lastId;
        }
    }

    private void executionAlert(boolean buy, double q, double p, String venue) {
        String title = String.format(Locale.UK, "🐋 %s %s market %s", fmtQty(q), coin, buy ? "BUY" : "SELL");
        String text = String.format(Locale.UK, "%s at %s (%s)", venue, fmtPrice(p), fmtUsd(q * p));
        alert(buy ? "buy" : "sell", title, text, true);
    }

    /** Whale walls placed, pulled or hit since the previous check. */
    private void checkWalls(double whale, double range) {
        Map<String, double[][][]> books = new HashMap<>();
        fetchBook(books, "Binance perp", "https://fapi.binance.com/fapi/v1/depth?symbol=" + sym[0] + "&limit=1000", "binance");
        fetchBook(books, "Binance spot", "https://api.binance.com/api/v3/depth?symbol=" + sym[0] + "&limit=1000", "binance");
        fetchBook(books, "Bybit perp", "https://api.bybit.com/v5/market/orderbook?category=linear&symbol=" + sym[4] + "&limit=500", "bybit");
        fetchBook(books, "OKX spot", "https://www.okx.com/api/v5/market/books?instId=" + sym[3] + "&sz=400", "okx");
        fetchBook(books, "Kraken", "https://api.kraken.com/0/public/Depth?pair=" + sym[2] + "&count=500", "kraken");

        Set<String> okVenues = books.keySet();
        Map<String, Double> mids = new HashMap<>();
        List<Wall> current = new ArrayList<>();
        for (Map.Entry<String, double[][][]> e : books.entrySet()) {
            double[][] bids = e.getValue()[0], asks = e.getValue()[1];
            if (bids.length == 0 || asks.length == 0) continue;
            double mid = (bids[0][0] + asks[0][0]) / 2;
            mids.put(e.getKey(), mid);
            for (double[] l : bids) if (l[1] >= whale && l[0] >= mid * (1 - range)) current.add(wall(e.getKey(), "bid", l));
            for (double[] l : asks) if (l[1] >= whale && l[0] <= mid * (1 + range)) current.add(wall(e.getKey(), "ask", l));
        }

        Map<String, Wall> next = new HashMap<>();
        Set<String> matchedPrev = new HashSet<>();
        for (Wall w : current) {
            Wall prev = null;
            String prevKey = null;
            for (Map.Entry<String, Wall> pe : st.walls.entrySet()) {
                Wall p = pe.getValue();
                if (p.venue.equals(w.venue) && p.side.equals(w.side) && Math.abs(p.price - w.price) / w.price <= 0.0005 && !matchedPrev.contains(pe.getKey())) {
                    prev = p;
                    prevKey = pe.getKey();
                    break;
                }
            }
            if (prev != null) {
                matchedPrev.add(prevKey);
                w.seen = prev.seen + 1;
                w.alerted = prev.alerted;
            } else {
                w.seen = 1;
                w.alerted = first; // walls already there when alerts start are not "new"
            }
            if (!w.alerted && w.seen >= 2) {
                w.alerted = true;
                Double mid = mids.get(w.venue);
                double dist = mid == null ? 0 : (w.price - mid) / mid * 100;
                alert("wall", String.format(Locale.UK, "🐋 New %s %s %s wall at %s", fmtQty(w.qty), coin, w.side, fmtPrice(w.price)),
                        String.format(Locale.UK, "%s · %+.2f%% from price · %s", w.venue, dist, fmtUsd(w.qty * w.price)), true);
            }
            next.put(w.venue + "|" + w.side + "|" + w.price, w);
        }

        // walls that disappeared
        for (Map.Entry<String, Wall> pe : st.walls.entrySet()) {
            if (matchedPrev.contains(pe.getKey())) continue;
            Wall p = pe.getValue();
            if (!okVenues.contains(p.venue)) { next.put(pe.getKey(), p); continue; } // venue didn't answer: keep
            if (p.seen < 2 || first) continue;
            Double mid = mids.get(p.venue);
            if (mid == null) continue;
            boolean reached = "bid".equals(p.side) ? mid <= p.price * 1.0005 : mid >= p.price * 0.9995;
            if (reached) {
                alert("wall", String.format(Locale.UK, "💥 %s %s %s wall at %s was hit", fmtQty(p.qty), coin, p.side, fmtPrice(p.price)),
                        p.venue + " · price reached it and the wall is gone", true);
            } else {
                alert("wall", String.format(Locale.UK, "👻 %s %s %s wall at %s pulled", fmtQty(p.qty), coin, p.side, fmtPrice(p.price)),
                        String.format(Locale.UK, "%s · removed before price got there (%+.2f%% away)", p.venue, (p.price - mid) / mid * 100), true);
            }
        }
        st.walls.clear();
        st.walls.putAll(next);
    }

    private static Wall wall(String venue, String side, double[] l) {
        Wall w = new Wall();
        w.venue = venue;
        w.side = side;
        w.price = l[0];
        w.qty = l[1];
        return w;
    }

    private void fetchBook(Map<String, double[][][]> out, String venue, String url, String kind) {
        try {
            JSONObject o = new JSONObject(get(url));
            JSONArray b, a;
            switch (kind) {
                case "bybit":
                    b = o.getJSONObject("result").getJSONArray("b");
                    a = o.getJSONObject("result").getJSONArray("a");
                    break;
                case "okx":
                    JSONObject d = o.getJSONArray("data").getJSONObject(0);
                    b = d.getJSONArray("bids");
                    a = d.getJSONArray("asks");
                    break;
                case "kraken":
                    JSONObject r = o.getJSONObject("result");
                    JSONObject pair = r.getJSONObject(r.keys().next());
                    b = pair.getJSONArray("bids");
                    a = pair.getJSONArray("asks");
                    break;
                default:
                    b = o.getJSONArray("bids");
                    a = o.getJSONArray("asks");
            }
            out.put(venue, new double[][][]{levels(b), levels(a)});
        } catch (Exception ignored) {
        }
    }

    private static double[][] levels(JSONArray arr) throws Exception {
        double[][] out = new double[arr.length()][2];
        for (int i = 0; i < arr.length(); i++) {
            JSONArray l = arr.getJSONArray(i);
            out[i][0] = Double.parseDouble(l.getString(0));
            out[i][1] = Double.parseDouble(l.getString(1));
        }
        return out;
    }

    // ------------------------------------------------------------------ notifications

    private void alert(String kind, String title, String text, boolean groupable) {
        Prefs.addAlert(this, kind, title, text);
        // cap notifications per check; extras are rolled into one summary
        if (groupable && alertsThisCheck >= 4) {
            overflow.add(title.replaceAll("^\\S+\\s", ""));
            return;
        }
        alertsThisCheck++;
        show(title, text);
    }

    private void show(String title, String text) {
        Notification.Builder nb = builder(CH_ALERT)
                .setContentTitle(title)
                .setContentText(text)
                .setStyle(new Notification.BigTextStyle().bigText(text))
                .setAutoCancel(true)
                .setWhen(System.currentTimeMillis())
                .setShowWhen(true);
        if (Build.VERSION.SDK_INT < 26) {
            nb.setPriority(Notification.PRIORITY_HIGH).setDefaults(Notification.DEFAULT_ALL);
        }
        nm.notify(nextAlertId++, nb.build());
        if (nextAlertId > 10_000) nextAlertId = 100;
    }

    private Notification statusNotification(String text) {
        return builder(CH_STATUS)
                .setContentTitle("Whale Book is watching")
                .setContentText(text)
                .setOngoing(true)
                .build();
    }

    private void updateStatus(String text) {
        if (nm != null) nm.notify(STATUS_ID, statusNotification(text));
    }

    private Notification.Builder builder(String channel) {
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, channel)
                : new Notification.Builder(this);
        Intent open = new Intent(this, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return b.setSmallIcon(R.drawable.ic_stat).setContentIntent(pi);
    }

    // ------------------------------------------------------------------ helpers

    private static String get(String u) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
        c.setConnectTimeout(8000);
        c.setReadTimeout(12000);
        c.setRequestProperty("User-Agent", "BTCWhaleBook/1.2");
        try {
            int code = c.getResponseCode();
            if (code != 200) throw new Exception("HTTP " + code);
            try (InputStream in = c.getInputStream()) {
                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                byte[] buf = new byte[16384];
                int n;
                while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
                return bo.toString("UTF-8");
            }
        } finally {
            c.disconnect();
        }
    }

    private static String fmtQty(double q) {
        if (q >= 1e6) return String.format(Locale.UK, "%.2fM", q / 1e6);
        return q >= 100 ? String.format(Locale.UK, "%,.0f", q) : String.format(Locale.UK, "%.1f", q);
    }

    private static String fmtPrice(double p) {
        if (p >= 1000) return String.format(Locale.UK, "$%,.0f", p);
        if (p >= 10) return String.format(Locale.UK, "$%,.2f", p);
        return String.format(Locale.UK, "$%.4f", p);
    }

    private static String fmtSigned(double v) {
        return (v >= 0 ? "+" : "−") + fmtQty(Math.abs(v));
    }

    private static String fmtUsd(double v) {
        if (v >= 1e9) return String.format(Locale.UK, "$%.2fB", v / 1e9);
        if (v >= 1e6) return String.format(Locale.UK, "$%.1fM", v / 1e6);
        return String.format(Locale.UK, "$%.0fk", v / 1e3);
    }
}
