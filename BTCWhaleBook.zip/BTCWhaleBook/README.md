# BTC Whale Book (Android)

Android app wrapping the BTC Whale Book dashboard. The dashboard lives in
`app/src/main/assets/index.html`; edit that file to change the app.

## Get the APK (no Android Studio needed)
1. Create a new repository on github.com and upload this folder's contents.
2. Open the **Actions** tab. The "Build APK" job runs on every push (or press "Run workflow").
3. When it finishes (about 3–5 minutes), open the run and download **BTC-Whale-Book-APK**.
4. Unzip it, copy `app-debug.apk` to your phone, tap it, and allow "Install unknown apps" when asked.

## Or with Android Studio
Open this folder, let it sync, then Build > Build APK(s).
