# BTC Liq Map

Android app showing an estimated liquidation map (all leverage together) for BTC, ETH and SOL perps.
The whole screen is `app/src/main/assets/index.html`; edit that file to change the app.

## Build the APK on GitHub
1. Upload `BTCLiqMap.zip` to the repository.
2. Add `.github/workflows/build-liqmap.yml` (see below).
3. Open **Actions**, wait for "Build Liq Map APK" to finish, download **BTC-Liq-Map-APK**.

```yaml
name: Build Liq Map APK
on: [push, workflow_dispatch]
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - run: unzip -o BTCLiqMap.zip
      - uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: '17'
      - uses: gradle/actions/setup-gradle@v4
        with:
          gradle-version: '8.7'
      - run: gradle assembleDebug --no-daemon
        working-directory: BTCLiqMap
      - uses: actions/upload-artifact@v4
        with:
          name: BTC-Liq-Map-APK
          path: BTCLiqMap/app/build/outputs/apk/debug/app-debug.apk
```
