package uk.kamdan.confluence;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;

import org.json.JSONObject;

import java.util.Iterator;

/** Remembers the last score per coin and posts a notification when a coin reaches 8/9 or 9/9. */
final class Alerts {
    static final String CHANNEL = "signals";

    static void createChannel(Context c) {
        try { createChannelInner(c); } catch (Throwable ignored) { }
    }

    private static void createChannelInner(Context c) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Confluence signals", NotificationManager.IMPORTANCE_HIGH));
    }

    /** json = {"BTC":{"score":8,"dir":1,"price":60000}, ...}. notify=false just records what the user has already seen in the app. */
    static void update(Context c, String json, boolean notify) {
        try {
            JSONObject o = new JSONObject(json);
            SharedPreferences sp = c.getSharedPreferences("alerts_bg", Context.MODE_PRIVATE);
            SharedPreferences.Editor ed = sp.edit();
            Iterator<String> it = o.keys();
            while (it.hasNext()) {
                String coin = it.next();
                JSONObject x = o.getJSONObject(coin);
                int score = x.getInt("score");
                int dir = x.getInt("dir");
                String key = score + (dir > 0 ? "L" : "S");
                String prev = sp.getString(coin, "");
                int prevScore = 0;
                String prevSide = "";
                if (prev.length() >= 2) {
                    try { prevScore = Integer.parseInt(prev.substring(0, prev.length() - 1)); } catch (NumberFormatException ignored) { }
                    prevSide = prev.substring(prev.length() - 1);
                }
                boolean rose = score > prevScore || !prevSide.equals(dir > 0 ? "L" : "S");
                if (notify && score >= 8 && rose) post(c, coin, score, dir, x.optDouble("price", 0));
                ed.putString(coin, key);
            }
            ed.apply();
        } catch (Exception ignored) { }
    }

    static void post(Context c, String coin, int score, int dir, double price) {
        if (Build.VERSION.SDK_INT >= 33 && c.checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) return;
        createChannel(c);
        String side = dir > 0 ? "LONG" : "SHORT";
        String title = coin + " " + score + "/9 " + side;
        String text;
        if (coin.equals("TEST")) { title = "Confluence test alert"; price = 0; }
        if (score >= 9) text = dir > 0 ? "All 9 checks agree: the tested long edge. Open the app for entry, stop and size."
                                       : "All 9 checks agree: short (weaker edge, half size). Open the app for the plan.";
        else text = "8 of 9 checks agree. One missing: open the app to see which.";
        if (coin.equals("TEST")) text = "Alerts are working. You'll get one like this when a coin reaches 8/9 or 9/9.";
        if (price > 0) text = "Price " + (price >= 100 ? String.format(java.util.Locale.UK, "%,.0f", price) : String.format(java.util.Locale.UK, "%.2f", price)) + ". " + text;
        Intent i = new Intent(c, MainActivity.class);
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(c, coin.hashCode(), i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification n = new Notification.Builder(c, CHANNEL)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle(title)
                .setContentText(text)
                .setStyle(new Notification.BigTextStyle().bigText(text))
                .setContentIntent(pi)
                .setAutoCancel(true)
                .build();
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.notify(coin.hashCode(), n);
    }
}
