package uk.kamdan.confluence;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.webkit.JavascriptInterface;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    private WebView web;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        final Thread.UncaughtExceptionHandler prev = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler((th, ex) -> {     // keep the crash so the page can show it next time
            try {
                java.io.StringWriter sw = new java.io.StringWriter();
                ex.printStackTrace(new java.io.PrintWriter(sw));
                getSharedPreferences("crash", MODE_PRIVATE).edit().putString("last", sw.toString()).commit();
            } catch (Throwable ignored) { }
            if (prev != null) prev.uncaughtException(th, ex);
        });
        web = new WebView(this);
        web.setBackgroundColor(0xFF1A0F1F);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);                 // keeps the journal between visits
        s.setAllowFileAccess(true);
        s.setAllowUniversalAccessFromFileURLs(true);  // lets the page call exchange APIs directly
        s.setCacheMode(WebSettings.LOAD_NO_CACHE);    // always fresh data
        s.setUserAgentString(s.getUserAgentString() + " ConfluenceApp");  // tells the page it is inside the app
        web.addJavascriptInterface(new Bridge(), "Android");  // export button: copy + share sheet
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean onRenderProcessGone(WebView v, android.webkit.RenderProcessGoneDetail d) {
                try { getSharedPreferences("crash", MODE_PRIVATE).edit().putString("last", "WebView page engine stopped (crash=" + d.didCrash() + ")").commit(); } catch (Throwable ignored) { }
                recreate();          // reopen the page instead of closing the app
                return true;
            }
        });
        setContentView(web);
        Alerts.createChannel(this);
        try {
            if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED)
                requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 1);
        } catch (Throwable ignored) { }
        AlertJob.schedule(this);
        web.loadUrl("file:///android_asset/index.html");
    }

    class Bridge {
        @JavascriptInterface public boolean isBg() { return false; }
        @JavascriptInterface public void done(String json) { }
        @JavascriptInterface public String lastCrash() {
            try {
                android.content.SharedPreferences sp = getSharedPreferences("crash", MODE_PRIVATE);
                String c = sp.getString("last", "");
                sp.edit().remove("last").apply();
                return c;
            } catch (Throwable t) { return ""; }
        }
        @JavascriptInterface public void fail(String err) { }
        /** Sends a test notification. Returns ok / noperm / off / error text, and opens the notification settings if they are blocked. */
        @JavascriptInterface public String testAlert() {
            try {
                Context c = getApplicationContext();
                boolean perm = Build.VERSION.SDK_INT < 33 || c.checkSelfPermission("android.permission.POST_NOTIFICATIONS") == PackageManager.PERMISSION_GRANTED;
                android.app.NotificationManager nm = (android.app.NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
                boolean on = nm == null || nm.areNotificationsEnabled();
                if (!perm || !on) {
                    runOnUiThread(() -> {
                        try {
                            Intent i = new Intent(android.provider.Settings.ACTION_APP_NOTIFICATION_SETTINGS);
                            i.putExtra(android.provider.Settings.EXTRA_APP_PACKAGE, getPackageName());
                            startActivity(i);
                        } catch (Throwable ignored) { }
                    });
                    return perm ? "off" : "noperm";
                }
                Alerts.post(c, "TEST", 9, 1, 0);
                return "ok";
            } catch (Throwable t) {
                return "error: " + t;
            }
        }
        @JavascriptInterface
        public void share(String text) {
            runOnUiThread(() -> {
                ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("Confluence export", text));
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("text/plain");
                i.putExtra(Intent.EXTRA_SUBJECT, "Confluence export");
                i.putExtra(Intent.EXTRA_TEXT, text);
                startActivity(Intent.createChooser(i, "Send export"));
            });
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        web.onResume();
    }

    @Override
    protected void onPause() {
        web.onPause();
        super.onPause();
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }
}
