package uk.kamdan.confluence;

import android.app.job.JobInfo;
import android.app.job.JobParameters;
import android.app.job.JobScheduler;
import android.app.job.JobService;
import android.content.ComponentName;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

/** Runs every hour in the background: loads the same page invisibly, which refreshes the checks,
 *  updates the signal tracker, and reports the scores back here for alerts. */
public class AlertJob extends JobService {
    static final int JOB_ID = 7101;
    private final Handler main = new Handler(Looper.getMainLooper());
    private WebView web;
    private JobParameters params;
    private boolean finished;

    static void schedule(Context c) {
        try { scheduleInner(c); } catch (Throwable ignored) { }
    }

    private static void scheduleInner(Context c) {
        JobScheduler js = (JobScheduler) c.getSystemService(Context.JOB_SCHEDULER_SERVICE);
        if (js == null || js.getPendingJob(JOB_ID) != null) return;
        JobInfo job = new JobInfo.Builder(JOB_ID, new ComponentName(c, AlertJob.class))
                .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                .setPeriodic(60L * 60 * 1000, 15L * 60 * 1000)
                .setPersisted(true)
                .build();
        js.schedule(job);
    }

    @Override
    public boolean onStartJob(JobParameters p) {
        params = p;
        finished = false;
        try {
            if (android.os.Build.VERSION.SDK_INT >= 28) {
                try { WebView.setDataDirectorySuffix("alerts"); } catch (Throwable ignored) { }   // once per process
            }
            web = new WebView(getApplicationContext());
            WebSettings s = web.getSettings();
            s.setJavaScriptEnabled(true);
            s.setDomStorageEnabled(true);
            s.setAllowFileAccess(true);
            s.setAllowUniversalAccessFromFileURLs(true);
            s.setCacheMode(WebSettings.LOAD_NO_CACHE);
            s.setUserAgentString(s.getUserAgentString() + " ConfluenceApp");
            web.addJavascriptInterface(new BgBridge(), "Android");
            web.setWebViewClient(new WebViewClient() {
                @Override
                public boolean onRenderProcessGone(WebView v, android.webkit.RenderProcessGoneDetail d) {
                    web = null;
                    main.post(AlertJob.this::finish);
                    return true;
                }
            });
            web.resumeTimers();
            web.loadUrl("file:///android_asset/index.html");
            main.postDelayed(this::finish, 120_000);   // give up after 2 minutes
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    private void finish() {
        if (finished) return;
        finished = true;
        main.removeCallbacksAndMessages(null);
        try { if (web != null) { web.destroy(); web = null; } } catch (Throwable ignored) { }
        try { jobFinished(params, false); } catch (Throwable ignored) { }
    }

    @Override
    public boolean onStopJob(JobParameters p) {
        finished = true;
        main.removeCallbacksAndMessages(null);
        main.post(() -> { if (web != null) { web.destroy(); web = null; } });
        return false;
    }

    class BgBridge {
        @JavascriptInterface public boolean isBg() { return true; }
        @JavascriptInterface public void done(String json) {
            try { Alerts.update(getApplicationContext(), json, true); } catch (Throwable ignored) { }
            main.post(AlertJob.this::finish);
        }
        @JavascriptInterface public void fail(String err) { main.post(AlertJob.this::finish); }
        @JavascriptInterface public void share(String text) { }
        @JavascriptInterface public void testAlert() { }
    }
}
