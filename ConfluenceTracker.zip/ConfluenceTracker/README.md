# Confluence Tracker

Android app: BTC, ETH and SOL with live price, the 9 tested daily confluences (long and short), entry / stop / target, and a trade journal.
The whole screen is `app/src/main/assets/index.html`; edit that file to change the app.

## Build the APK on GitHub
1. Upload `ConfluenceTracker.zip` to the repository (same repo as the other apps is fine).
2. Add `.github/workflows/build-confluence.yml` (the file sent with this zip).
3. Open **Actions**, wait for "Build Confluence APK" to finish, download **Confluence-APK**.
